import React, { useState, useEffect } from 'react';
import {   UploadCloud, FileType, CheckCircle, Play, Settings, List, Link, FileText, Terminal, Cpu, WifiOff, BookOpen  } from 'lucide-react';
import axios from 'axios';
import { Toaster, toast } from 'sonner';
import Tasks from './components/Tasks';
import Docs from './components/Docs';
import Guidelines from './components/Guidelines';

export default function App() {
  const [activeTab, setActiveTab] = useState<'upload' | 'settings' | 'tasks' | 'guidelines' | 'docs'>('upload');
  
  // Settings State
  const [sshHost, setSshHost] = useState(localStorage.getItem('sshHost') || '1.2.268.1.100');
  const [sshPort, setSshPort] = useState(localStorage.getItem('sshPort') || '22');
  const [sshUser, setSshUser] = useState(localStorage.getItem('sshUser') || '');
  const [sshPass, setSshPass] = useState(localStorage.getItem('sshPass') || '');
  const [remoteBasePath, setRemoteBasePath] = useState(localStorage.getItem('remoteBasePath') || '/share/users/zengxin/workspace/TAP_TNP');
  const [condaProfile, setCondaProfile] = useState(localStorage.getItem('condaProfile') || '/share/software/miniforge3/etc/profile.d/conda.sh');
  const [ibEnv, setIbEnv] = useState(localStorage.getItem('ibEnv') || 'immunebuilder');
  const [psaBin, setPsaBin] = useState(localStorage.getItem('psaBin') || '/share/users/zengxin/data/AI_tools/TNP/bin/psa');
      const [sshConnected, setSshConnected] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);


  // Save settings on change
  useEffect(() => {
    localStorage.setItem('sshHost', sshHost);
    localStorage.setItem('sshPort', sshPort);
    localStorage.setItem('sshUser', sshUser);
    localStorage.setItem('sshPass', sshPass);
    localStorage.setItem('remoteBasePath', remoteBasePath);
    localStorage.setItem('condaProfile', condaProfile);
    localStorage.setItem('ibEnv', ibEnv);
    localStorage.setItem('psaBin', psaBin);
          }, [sshHost, sshPort, sshUser, sshPass, remoteBasePath, condaProfile, ibEnv, psaBin, ]);


  const uploadCustomReference = async (type: 'tap' | 'tnp', file: File) => {
    const formData = new FormData();
    formData.append('file', file);
    try {
      const res = await axios.post('/api/upload/' + type, formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      toast.success('Successfully uploaded custom reference file. Guidelines updated.');
      setRefreshKey(prev => prev + 1);
      // Force reload to update guidelines if needed (or let the user navigate)
    } catch (e: any) {
      toast.error('Failed to upload: ' + (e.response?.data?.error || e.message));
    }
  };

  const resetCustomReference = async () => {
    try {
      await axios.post('/api/upload/reset');
      
      // Reset all settings states to defaults
      setSshHost('');
      setSshPort('22');
      setSshUser('');
      setSshPass('');
      setRemoteBasePath('/share/users/zengxin/data/AI_tools/TNP/run_Immunebuilder/output_dir');
      setCondaProfile('/share/software/miniforge3/etc/profile.d/conda.sh');
      setIbEnv('immunebuilder');
      setPsaBin('/share/users/zengxin/data/AI_tools/TNP/bin/psa');
      
      toast.success('All settings and references have been reset to defaults.');
      setRefreshKey(prev => prev + 1);
    } catch (e: any) {
      toast.error('Failed to reset: ' + (e.response?.data?.error || e.message));
    }
  };

  const connectSsh = async (): Promise<boolean> => {
    try {
      await axios.post('/api/ssh/connect', {
        sshHost, sshPort, sshUser, sshPass, remoteBasePath
      });
      setSshConnected(true);
      return true;
    } catch (err: any) {
      setSshConnected(false);
      toast.error('Failed to connect via SSH: ' + (err.response?.data?.message || err.message));
      return false;
    }
  };

  const disconnectSsh = async () => {
    try {
      await axios.post('/api/ssh/disconnect');
      setSshConnected(false);
    } catch (err) {
      toast.error('Failed to disconnect SSH.');
    }
  };

  useEffect(() => {
    if (sshHost && sshUser && sshPass) {
      axios.get('/api/ssh/status').then(res => {
        setSshConnected(res.data.connected);
      }).catch(() => setSshConnected(false));
    }
  }, []);

  // Job State
  const [files, setFiles] = useState<File[]>([]);
  const [mode, setMode] = useState<'fasta' | 'structure'>('fasta');
  const [isDragging, setIsDragging] = useState(false);
  
  const generateRandomId = () => {
    const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    return 'proj_' + Array.from({ length: 6 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
  };
  const [projectId, setProjectId] = useState<string>(generateRandomId());
  
  // Status
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFiles(Array.from(e.target.files));
    }
  };

  const handleSubmit = async () => {
    if (files.length === 0) {
      toast.error('Please upload files first.');
      return;
    }
    if (!remoteBasePath) {
      toast.error('Remote Base Path is required. Please configure it in settings.');
      setActiveTab('settings');
      return;
    }
    
    let isConnected = sshConnected;
    if (!isConnected) {
      isConnected = await connectSsh();
      if (!isConnected) return;
    }

    setIsSubmitting(true);
    
    try {
      const zipData: Record<string, Uint8Array> = {};
      for (const file of files) {
        const buf = await file.arrayBuffer();
        zipData[file.name] = new Uint8Array(buf);
      }
      
      const { zipSync } = await import('fflate');
      const zipped = zipSync(zipData);
      
      // Efficiently convert Uint8Array to Base64
      const chunks = [];
      const chunkSize = 8192;
      for (let i = 0; i < zipped.length; i += chunkSize) {
        chunks.push(String.fromCharCode.apply(null, Array.from(zipped.subarray(i, i + chunkSize))));
      }
      const zipPayload = btoa(chunks.join(''));

      await axios.post('/api/submit', {
        zipPayload,
        remoteBasePath,
        condaProfile,
        ibEnv,
        psaBin,
        mode,
        projectId,
        
      });
      toast.success('Job submitted successfully!');
      setActiveTab('tasks');
      setFiles([]);
      setProjectId(generateRandomId());
    } catch (err: any) {
      const errorMsg = err.response?.data?.error || err.message;
      if (typeof errorMsg === 'string' && (errorMsg.includes('SSH Client is not connected') || errorMsg.includes('SSH Config is missing'))) {
        setSshConnected(false);
        const retryConnected = await connectSsh();
        if (retryConnected) {
          try {
            const formData = new FormData();
      files.forEach(f => {
        formData.append('files', f);
      });
      formData.append('remoteBasePath', remoteBasePath);
      formData.append('condaProfile', condaProfile);
      formData.append('ibEnv', ibEnv);
      formData.append('psaBin', psaBin);
      formData.append('mode', mode);
      formData.append('projectId', projectId);
      
      await axios.post('/api/submit', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
            toast.success('Job submitted successfully!');
            setActiveTab('tasks');
            setFiles([]);
            setProjectId(generateRandomId());
            return;
          } catch (retryErr: any) {
            toast.error('Error submitting job: ' + (retryErr.response?.data?.error || retryErr.message));
            return;
          }
        }
      }
      toast.error('Error submitting job: ' + errorMsg);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-surface-50 flex flex-col text-surface-900">
      <Toaster position="top-right" richColors />
      <header className="bg-white border-b border-surface-200 px-6 py-4 flex flex-col md:flex-row md:items-center justify-between gap-4 sticky top-0 z-40 shadow-sm">
        <div className="flex items-center gap-3 text-xl font-bold text-surface-900">
          <div className="w-10 h-10 bg-brand-600 rounded-xl flex items-center justify-center shadow-sm">
            <FileType className="text-white w-6 h-6" />
          </div>
          <div className="flex flex-col">
            <h1 className="leading-tight font-display tracking-tight">Therapeutic Antibody Profiler_IB</h1>
            <span className="text-brand-600 text-[10px] uppercase tracking-wider font-bold font-mono">v3.3.0</span>
          </div>
        </div>
        <div className="flex flex-wrap gap-1 md:gap-2 items-center">
          <div className="flex items-center gap-2 text-sm font-medium mr-2 md:mr-6 bg-surface-100 px-3 py-1.5 rounded-full border border-surface-200">
            <span className={`w-2 h-2 rounded-full ${sshConnected ? 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]' : 'bg-rose-500'}`}></span>
            <span className="hidden sm:inline text-surface-600 font-mono text-xs">{sshConnected ? 'CLUSTER CONNECTED' : 'DISCONNECTED'}</span>
          </div>
          
          <button onClick={() => setActiveTab('upload')} className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all ${activeTab === 'upload' ? 'bg-brand-600 text-white shadow-md' : 'text-surface-600 hover:bg-surface-100'}`}>Upload</button>
          <button onClick={() => setActiveTab('tasks')} className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all ${activeTab === 'tasks' ? 'bg-brand-600 text-white shadow-md' : 'text-surface-600 hover:bg-surface-100'}`}>Results</button>
          <button onClick={() => setActiveTab('guidelines')} className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all flex items-center gap-1.5 ${activeTab === 'guidelines' ? 'bg-brand-600 text-white shadow-md' : 'text-surface-600 hover:bg-surface-100'}`}><BookOpen size={16} />Guidelines</button>
          <button onClick={() => setActiveTab('docs')} className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all flex items-center gap-1.5 ${activeTab === 'docs' ? 'bg-brand-600 text-white shadow-md' : 'text-surface-600 hover:bg-surface-100'}`}><FileText size={16} />Docs</button>
          <button onClick={() => setActiveTab('settings')} className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all flex items-center gap-1.5 ${activeTab === 'settings' ? 'bg-brand-600 text-white shadow-md' : 'text-surface-600 hover:bg-surface-100'}`}><Settings size={16}/>Settings</button>

        </div>
      </header>

      <main className="flex-1 p-6 md:p-10 max-w-7xl mx-auto w-full">
        {activeTab === 'settings' && (
          <div className="bg-white p-8 rounded-2xl shadow-sm border border-surface-200 max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-2 duration-300">
            <div>
              <div className="text-lg font-bold border-b border-surface-200 pb-4 mb-6 flex items-center justify-between font-display">
                <div className="flex items-center gap-2 text-surface-900">
                  <div className="p-1.5 bg-brand-50 rounded-lg"><Settings size={20} className="text-brand-600"/></div>
                  SSH Connection
                </div>
                <div className="flex items-center gap-2">
                  <button onClick={connectSsh} className="text-sm bg-surface-900 hover:bg-surface-800 transition-colors text-white px-4 py-2 rounded-xl flex items-center gap-2 font-medium"><Link size={14}/> Connect</button>
                  <button onClick={disconnectSsh} disabled={!sshConnected} className="text-sm bg-rose-50 hover:bg-rose-100 text-rose-600 disabled:opacity-50 transition-colors px-4 py-2 rounded-xl flex items-center gap-2 font-medium"><WifiOff size={14}/> Disconnect</button>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-1.5">
                  <label className="block text-sm font-semibold text-surface-700">Host</label>
                  <input type="text" value={sshHost} onChange={e => setSshHost(e.target.value)} className="w-full bg-surface-50 border border-surface-200 rounded-xl px-4 py-2.5 focus:bg-white focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500 outline-none transition-all font-mono text-sm" />
                </div>
                <div className="space-y-1.5">
                  <label className="block text-sm font-semibold text-surface-700">Port</label>
                  <input type="text" value={sshPort} onChange={e => setSshPort(e.target.value)} className="w-full bg-surface-50 border border-surface-200 rounded-xl px-4 py-2.5 focus:bg-white focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500 outline-none transition-all font-mono text-sm" />
                </div>
                <div className="space-y-1.5">
                  <label className="block text-sm font-semibold text-surface-700">Username</label>
                  <input type="text" value={sshUser} onChange={e => setSshUser(e.target.value)} className="w-full bg-surface-50 border border-surface-200 rounded-xl px-4 py-2.5 focus:bg-white focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500 outline-none transition-all font-mono text-sm" />
                </div>
                <div className="space-y-1.5">
                  <label className="block text-sm font-semibold text-surface-700">Password</label>
                  <input type="password" value={sshPass} onChange={e => setSshPass(e.target.value)} className="w-full bg-surface-50 border border-surface-200 rounded-xl px-4 py-2.5 focus:bg-white focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500 outline-none transition-all font-mono text-sm" />
                </div>
              </div>
            </div>

            <div>
              <div className="text-lg font-bold border-b border-surface-200 pb-4 mb-6 flex items-center gap-2 text-surface-900 font-display">
                <div className="p-1.5 bg-emerald-50 rounded-lg"><Terminal size={20} className="text-emerald-600" /></div>
                Workspace & Environment
              </div>
              <div className="space-y-6">
                <div className="space-y-1.5">
                  <label className="block text-sm font-semibold text-surface-700">Remote Base Path</label>
                  <input type="text" value={remoteBasePath} onChange={e => setRemoteBasePath(e.target.value)} className="w-full bg-surface-50 border border-surface-200 rounded-xl px-4 py-2.5 focus:bg-white focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500 outline-none transition-all font-mono text-sm" />
                </div>
                <div className="space-y-1.5">
                  <label className="block text-sm font-semibold text-surface-700">Conda Profile Script</label>
                  <input type="text" value={condaProfile} onChange={e => setCondaProfile(e.target.value)} className="w-full bg-surface-50 border border-surface-200 rounded-xl px-4 py-2.5 focus:bg-white focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500 outline-none transition-all font-mono text-sm" />
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-semibold text-surface-700 flex items-center gap-1.5"><Cpu size={16} className="text-surface-400"/> ImmuneBuilder Environment Name</label>
                  <input type="text" value={ibEnv} onChange={e => setIbEnv(e.target.value)} className="w-full bg-surface-50 border border-surface-200 rounded-xl px-4 py-2.5 focus:bg-white focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500 outline-none transition-all font-mono text-sm" />
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-semibold text-surface-700 flex items-center gap-1.5"><Terminal size={16} className="text-surface-400"/> PSA Binary Path</label>
                  <input type="text" value={psaBin} onChange={e => setPsaBin(e.target.value)} className="w-full bg-surface-50 border border-surface-200 rounded-xl px-4 py-2.5 focus:bg-white focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500 outline-none transition-all font-mono text-sm" />
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-semibold text-surface-700 flex items-center gap-1.5"><FileText size={16} className="text-surface-400"/> Custom TAP Reference (CSV)</label>
                  <div className="flex gap-2">
                    <input type="file" accept=".csv" onChange={e => e.target.files && uploadCustomReference('tap', e.target.files[0])} className="w-full bg-surface-50 border border-surface-200 rounded-xl px-4 py-2 focus:bg-white focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500 outline-none transition-all text-sm file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-bold file:bg-brand-50 file:text-brand-700 hover:file:bg-brand-100" />
                  </div>
                  <p className="text-xs text-surface-500 pl-1">Leave empty to use built-in `Analysis_Results_TAP.csv`</p>
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-semibold text-surface-700 flex items-center gap-1.5"><FileText size={16} className="text-surface-400"/> Custom TNP Reference (CSV)</label>
                  <div className="flex gap-2">
                    <input type="file" accept=".csv" onChange={e => e.target.files && uploadCustomReference('tnp', e.target.files[0])} className="w-full bg-surface-50 border border-surface-200 rounded-xl px-4 py-2 focus:bg-white focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500 outline-none transition-all text-sm file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-bold file:bg-emerald-50 file:text-emerald-700 hover:file:bg-emerald-100" />
                  </div>
                  <p className="text-xs text-surface-500 pl-1">Leave empty to use built-in `Analysis_Results_TNP.csv`</p>
                </div>
                <div className="space-y-2 pt-2">
                  <button onClick={resetCustomReference} className="text-sm bg-surface-100 hover:bg-surface-200 text-surface-700 px-4 py-2 rounded-xl font-medium transition-colors border border-surface-200">
                    Reset All Settings & References to Defaults
                  </button>
                </div>

              </div>
            </div>
          </div>
        )}

        {activeTab === 'upload' && (
          <div className="space-y-6 max-w-4xl mx-auto animate-in fade-in slide-in-from-bottom-2 duration-300">
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-surface-200">
              <h2 className="text-xl font-bold mb-8 flex items-center gap-3 text-surface-900 border-b border-surface-200 pb-4 font-display">
                <div className="p-2 bg-brand-50 rounded-xl"><Settings size={20} className="text-brand-600"/></div>
                Pipeline Configuration
              </h2>
              
              <div className="mb-8 space-y-2">
                <div className="flex items-center justify-between px-1">
                  <label className="block text-xs font-bold text-surface-600 uppercase tracking-wider">Project ID / Task Name</label>
                  <button 
                    onClick={() => setProjectId(generateRandomId())}
                    className="text-xs text-brand-600 hover:text-brand-700 font-bold px-2 py-1 hover:bg-brand-50 rounded-md transition-colors"
                  >
                    Randomize
                  </button>
                </div>
                <input 
                  type="text" 
                  value={projectId}
                  onChange={e => setProjectId(e.target.value)}
                  placeholder="e.g. proj_xyz123"
                  className="w-full bg-surface-50 border border-surface-200 rounded-xl px-4 py-3 text-sm text-surface-900 focus:outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 transition-all font-mono" 
                />
              </div>

              <div className="mb-8">
                <label className="block text-xs font-bold mb-3 text-surface-600 uppercase tracking-wider">Input Mode</label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <label className={`flex items-center gap-3 px-4 py-4 border rounded-xl cursor-pointer transition-all ${mode === 'fasta' ? 'bg-brand-50 border-brand-300 text-brand-900 ring-1 ring-brand-300 shadow-sm' : 'hover:bg-surface-50 border-surface-200 text-surface-600'}`}>
                    <input type="radio" className="w-4 h-4 text-brand-600 focus:ring-brand-500 border-surface-300" checked={mode === 'fasta'} onChange={() => setMode('fasta')} />
                    <span className="font-semibold">Sequence (FASTA)</span>
                  </label>
                  <label className={`flex items-center gap-3 px-4 py-4 border rounded-xl cursor-pointer transition-all ${mode === 'structure' ? 'bg-brand-50 border-brand-300 text-brand-900 ring-1 ring-brand-300 shadow-sm' : 'hover:bg-surface-50 border-surface-200 text-surface-600'}`}>
                    <input type="radio" className="w-4 h-4 text-brand-600 focus:ring-brand-500 border-surface-300" checked={mode === 'structure'} onChange={() => setMode('structure')} />
                    <span className="font-semibold">Structure (PDB/CIF)</span>
                  </label>
                </div>
              </div>

              <div 
                className={`border-2 border-dashed rounded-2xl p-12 text-center transition-all cursor-pointer relative group ${isDragging ? 'border-brand-500 bg-brand-100/50 scale-[1.01]' : 'border-surface-200 bg-surface-50 hover:bg-surface-100 hover:border-brand-300'}`}
                onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={(e) => {
                  e.preventDefault();
                  setIsDragging(false);
                  if (e.dataTransfer.files) {
                    setFiles(Array.from(e.dataTransfer.files));
                  }
                }}
              >
                <input type="file" multiple onChange={handleFileChange} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" />
                <div className={`w-16 h-16 mx-auto mb-4 rounded-2xl flex items-center justify-center transition-colors ${isDragging ? 'bg-brand-200 text-brand-700' : 'bg-white shadow-sm text-surface-400 group-hover:text-brand-500'}`}>
                  <UploadCloud className={`transition-transform duration-300 ${isDragging ? 'scale-125' : 'group-hover:scale-110'}`} size={32} />
                </div>
                <p className={`font-bold text-lg mb-1 font-display ${isDragging ? 'text-brand-800' : 'text-surface-800'}`}>
                  {isDragging ? 'Drop files here!' : 'Click or drag files to upload'}
                </p>
                <p className="text-sm font-medium text-surface-500">Supports .fasta, .pdb, .cif (Multiple files allowed)</p>
              </div>

              {files.length > 0 && (
                <div className="mt-8 bg-surface-50 rounded-xl p-5 border border-surface-200">
                  <p className="text-xs font-bold text-surface-800 mb-4 flex items-center gap-2 uppercase tracking-wider">
                    <List size={16} className="text-brand-500"/>
                    Selected files ({files.length})
                  </p>
                  <ul className="text-sm text-surface-700 space-y-2 max-h-48 overflow-y-auto pr-2 custom-scrollbar font-medium">
                    {files.map((f, i) => (
                      <li key={i} className="flex items-center gap-3 bg-white px-4 py-2.5 rounded-lg border border-surface-100 shadow-sm">
                        <CheckCircle size={18} className="text-emerald-500 shrink-0"/> 
                        <span className="truncate">{f.name}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            <div className="flex justify-end pt-4">
              <button 
                onClick={handleSubmit} 
                disabled={isSubmitting || files.length === 0}
                className="bg-surface-900 hover:bg-surface-800 disabled:bg-surface-200 disabled:text-surface-400 text-white px-8 py-3.5 rounded-xl font-bold flex items-center gap-2 shadow-md transition-all w-full sm:w-auto justify-center text-base"
              >
                {isSubmitting ? <span className="animate-pulse">Submitting...</span> : <><Play size={20} /> Run Pipeline</>}
              </button>
            </div>
          </div>
        )}

        {activeTab === 'tasks' && (
          <Tasks sshConnected={sshConnected} remoteBasePath={remoteBasePath} />
        )}

        
        {activeTab === 'guidelines' && (
          <Guidelines sshConnected={sshConnected} refreshKey={refreshKey} />
        )}

        {activeTab === 'docs' && (
          <Docs />
        )}
      </main>
    </div>
  );
}
