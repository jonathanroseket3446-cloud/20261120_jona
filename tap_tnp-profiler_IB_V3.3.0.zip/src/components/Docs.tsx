import React, { useState } from 'react';
import { BookOpen, FileText, Activity, Shield, Database, BarChart3, Play, Cpu, Sparkles, Layers, Lightbulb, List, TableProperties } from 'lucide-react';

export default function Docs() {
  const [lang, setLang] = useState<'zh' | 'en'>('zh');

  const content = {
    en: {
      title: 'Platform Documentation',
      subtitle: 'Comprehensive guide to TAP/TNP metrics, 5-Tier Developability Evaluation, and Platform Architecture (v3.3.0)',
      intro: 'The platform integrates the latest Therapeutic Antibody Profiler (TAP 2024) and Therapeutic Nanobody Profiler (TNP 2025) algorithms. By combining sequence properties with highly accurate structural predictions (ImmuneBuilder/ABodyBuilder2), we provide actionable developability scores and structural flags. Version 3.3.0 introduces a refined 5-tier evaluation baseline derived from dynamic dataset percentiles.',
      sections: [
        {
          id: 'quick-start',
          title: 'Quick Start & Detailed Usage Guide',
          icon: <Play className="w-6 h-6 text-brand-600" />,
          body: (
            <div className="space-y-4">
              <p>Welcome to the TAP/TNP evaluation platform. This system evaluates the developability of therapeutic antibodies and nanobodies directly from sequence or structure files.</p>
              <h4 className="font-bold text-surface-800 mt-4 border-b pb-2">1. Connection Setup (Settings)</h4>
              <ul className="list-decimal pl-4 space-y-2">
                <li>Navigate to the <strong>Settings</strong> tab and configure your SSH credentials (Host, Port, User, Password).</li>
                <li>Ensure the <strong>Remote Base Path</strong> and <strong>Conda Profile</strong> are correctly pointing to the cluster's directory where ImmuneBuilder is installed.</li>
                <li>This allows the system to securely dispatch high-performance structural prediction tasks without overloading your local machine.</li>
              </ul>
              
              <h4 className="font-bold text-surface-800 mt-4 border-b pb-2">2. Dynamic Guidelines & Custom Baselines</h4>
              <ul className="list-decimal pl-4 space-y-2">
                <li>Under the <strong>Guidelines</strong> tab, you can visualize the statistical distribution (Box & Whisker plots) of clinical-stage antibodies (TheraSAbDab).</li>
                <li>You can upload your own custom reference CSV file to override the default TAP/TNP baseline. <em>Note: Custom references are persistent across reloads until explicitly reset.</em></li>
              </ul>

              <h4 className="font-bold text-surface-800 mt-4 border-b pb-2">3. Upload & Run Pipeline</h4>
              <ul className="list-decimal pl-4 space-y-2">
                <li>Go to the <strong>Upload</strong> tab and drop your <code>.fasta</code>, <code>.pdb</code>, or <code>.cif</code> files.</li>
                <li>Select the target mode: <strong>TAP (Conventional mAbs)</strong> or <strong>TNP (Nanobodies)</strong>.</li>
                <li>For sequence files, the system will automatically predict 3D structures using ABodyBuilder2 (for mAbs) or NanoBuilder2 (for VHHs) before passing them to the profiler.</li>
                <li>Click <em>Run Pipeline</em>. The task will be dispatched asynchronously.</li>
              </ul>

              <h4 className="font-bold text-surface-800 mt-4 border-b pb-2">4. Results & Export</h4>
              <ul className="list-decimal pl-4 space-y-2">
                <li>Check the <strong>Tasks</strong> tab to monitor real-time SSH execution logs.</li>
                <li>Once completed, click <strong>View Results</strong> to see the data table.</li>
                <li>Use the <strong>Export to Excel</strong> button to download a spreadsheet retaining all visual color gradings for reporting.</li>
              </ul>
            </div>
          )
        },
        {
          id: '5-tier-system',
          title: '5-Tier Evaluation System',
          icon: <Sparkles className="w-6 h-6 text-emerald-600" />,
          body: (
            <div className="space-y-4">
              <p>Version 3.3.0 replaces the legacy 3-color system with a highly nuanced <strong>5-Tier Color Evaluation System</strong> mapped directly to statistical quartiles and extreme percentiles of the reference dataset (e.g., TheraSAbDab).</p>
              <ul className="list-none space-y-4 mt-4">
                <li className="flex items-start gap-3">
                  <div className="mt-1 flex-shrink-0"><span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-rose-500 text-white font-bold text-[10px] uppercase border border-rose-600 shadow-sm">RED</span></div>
                  <div><strong>Extreme Risk:</strong> Property falls outside the 0th or 100th percentile of clinical-stage therapeutics. Indicates a severe developability liability (e.g., aggregation, high viscosity).</div>
                </li>
                <li className="flex items-start gap-3">
                  <div className="mt-1 flex-shrink-0"><span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-amber-400 text-amber-950 font-bold text-[10px] uppercase border border-amber-500 shadow-sm">AMBER</span></div>
                  <div><strong>High Risk:</strong> Property falls in the 0-5% or 95-100% boundary. Requires careful engineering, mutagenesis, or specialized formulation support.</div>
                </li>
                <li className="flex items-start gap-3">
                  <div className="mt-1 flex-shrink-0"><span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-emerald-200 text-emerald-950 font-bold text-[10px] uppercase border border-emerald-300 shadow-sm">L-GREEN</span></div>
                  <div><strong>Marginal Risk (Light Green):</strong> Property falls in the 5-10% or 90-95% boundary. Acceptable, but slightly deviating from typical clinical ranges.</div>
                </li>
                <li className="flex items-start gap-3">
                  <div className="mt-1 flex-shrink-0"><span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-emerald-400 text-emerald-950 font-bold text-[10px] uppercase border border-emerald-500 shadow-sm">M-GREEN</span></div>
                  <div><strong>Standard Range (Mid Green):</strong> Property falls in the 10-25% or 75-90% range. Considered generally safe and developable.</div>
                </li>
                <li className="flex items-start gap-3">
                  <div className="mt-1 flex-shrink-0"><span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-emerald-600 text-white font-bold text-[10px] uppercase border border-emerald-700 shadow-sm">D-GREEN</span></div>
                  <div><strong>Core Optimal Range (Dark Green):</strong> Property falls perfectly in the middle 25-75% interquartile range (IQR). Represents the safest and most robust developability profile.</div>
                </li>
              </ul>
              <p className="mt-4">This 5-tier evaluation is synchronized across the Web UI Tables, the SVG Box-and-Whisker Plots, and the exported Excel cell styles.</p>
            </div>
          )
        },
        {
          id: 'algo-details',
          title: 'Algorithms & Core Structural Parameters',
          icon: <Activity className="w-6 h-6 text-brand-600" />,
          body: (
            <div className="space-y-4">
              <p>The core evaluation engine identifies liabilities by analyzing 3D structural metrics against clinical-stage therapeutics benchmarks (Communications Biology, 2024). <strong>Note: You can configure the risk thresholds and percentiles via the Guidelines page or a custom reference file.</strong></p>
              
              <h4 className="font-bold text-surface-800 border-b pb-2 mt-4">TAP 2024 Guidelines (Conventional mAbs)</h4>
              <ul className="list-none space-y-4">
                <li>
                  <strong>Total CDR Length (L_tot):</strong> Calculated using IMGT numbering across all 6 CDRs. Extended loops increase conformational flexibility and aggregation risk.<br/>
                  <code className="text-sm bg-surface-100 px-1 py-0.5 rounded text-pink-600">Formula: ∑ Length(CDR_i) (i = H1,H2,H3,L1,L2,L3)</code><br/>
                  <span className="text-sm text-surface-500">Default Range: Green (42-55), Amber (37-42 & 55-63), Red (&lt;37 & &gt;63).</span>
                </li>
                <li>
                  <strong>Patches of Surface Hydrophobicity (PSH):</strong> Evaluated using the Kyte-Doolittle scale and Shrake-Rupley SASA (1.4Å probe). High PSH significantly increases intermolecular hydrophobic interactions and aggregation.<br/>
                  <code className="text-sm bg-surface-100 px-1 py-0.5 rounded text-pink-600">Formula: ∑ (SASA_i * Kyte-Doolittle_i) (Exposed residues only)</code><br/>
                  <span className="text-sm text-surface-500">Default Range: Green (110.11-168.06), Amber (95.58-110.11 & 168.06-201.59), Red (&lt;95.58 & &gt;201.59).</span>
                </li>
                <li>
                  <strong>Positive/Negative Charge Patches (PPC & PNC):</strong> Quantifies the clustering of charge on the Fv surface. Extreme charges lead to off-target binding and rapid clearance (PPC) or high viscosity (PNC).<br/>
                  <span className="text-sm text-surface-500">PPC Range: Green (≤1.32), Amber (1.32-4.22), Red (&gt;4.22). PNC Range: Green (≤2.00), Amber (2.00-4.42), Red (&gt;4.42).</span>
                </li>
                <li>
                  <strong>Structural Fv Charge Symmetry Parameter (SFvCSP):</strong> Measures charge asymmetry between VH and VL. Extreme negative values denote severe asymmetry, leading to solubility issues.<br/>
                  <code className="text-sm bg-surface-100 px-1 py-0.5 rounded text-pink-600">Logic: Analyzes Q_H (Heavy net charge) * Q_L (Light net charge) normalized by contact area.</code><br/>
                  <span className="text-sm text-surface-500">Range: Green (&gt;-6.00), Amber (-30.60 to -6.00), Red (&lt;-30.60).</span>
                </li>
              </ul>
              
              <h4 className="font-bold text-surface-800 border-b pb-2 mt-6">TNP 2025 Guidelines (Nanobodies / VHH)</h4>
              <p>Optimized for VHHs, accounting for long CDR3s and exposed FR2 tetrad residues (bioRxiv, 2025).</p>
              <ul className="list-none space-y-4">
                <li>
                  <strong>CDR Length (L) & CDR3 Length (L3):</strong> VHHs rely on longer CDR3s to reach cleft epitopes.<br/>
                  <span className="text-sm text-surface-500">L Range: Green (24-37.25), Red (&lt;20 & &gt;39). L3 Range: Green (8-21.25), Red (&lt;5 & &gt;23).</span>
                </li>
                <li>
                  <strong>CDR3 Compactness (C):</strong> A new metric defined as the structural span of CDR3 divided by its length.<br/>
                  <code className="text-sm bg-surface-100 px-1 py-0.5 rounded text-pink-600">Formula: Compactness = (Max Euclidean Distance) / L3 Length</code><br/>
                  <p className="text-sm text-surface-600">Displays bimodality: High compactness folds back onto FR2 (shielding hydrophobicity), low compactness points straight out.</p>
                  <span className="text-sm text-surface-500">Range: Green (0.81-1.57), Amber (0.56-0.81 & 1.57-1.61), Red (&lt;0.56 & &gt;1.61).</span>
                </li>
                <li>
                  <strong>PSH (TNP):</strong> Tuned for the unique surface morphology of the exposed FR2 tetrad.<br/>
                  <span className="text-sm text-surface-500">Range: Green (79.59-126.83), Amber (73.40-79.59 & 126.83-155.47), Red (&lt;73.40 & &gt;155.47).</span>
                </li>
                <li>
                  <strong>PPC & PNC (TNP):</strong> <br/>
                  <span className="text-sm text-surface-500">PPC Range: Green (≤0.39), Red (&gt;1.18). PNC Range: Green (≤1.47), Red (&gt;1.88).</span>
                </li>
              </ul>
            </div>
          )
        },
        {
          id: 'seq-properties',
          title: 'Sequence Properties (Physicochemical)',
          icon: <List className="w-6 h-6 text-brand-600" />,
          body: (
            <div className="space-y-4">
              <p>Calculated using Biopython/ProtParam standard algorithms. Results are dynamically benchmarked against the TheraSAbDab clinical baseline (VHVL N=1103, VHH N=28) using strict 5th (p5) and 95th (p95) percentile boundaries.</p>
              <ul className="list-disc pl-6 space-y-3 text-[15px]">
                <li><strong>Isoelectric Point (pI):</strong> The pH at which the protein's net charge is zero, minimizing intermolecular repulsion and drastically increasing precipitation risk. Formulation pH must avoid the pI.<br/>
                <code className="text-sm bg-surface-100 px-1 py-0.5 rounded text-pink-600">Logic: Uses Bjellqvist pK values, applying Newton's iteration to find pH where Net Charge Z = 0.</code></li>
                
                <li><strong>GRAVY (Grand Average of Hydropathy):</strong> Positive values indicate a globally hydrophobic sequence. Extremely high values represent a critical aggregation risk.<br/>
                <code className="text-sm bg-surface-100 px-1 py-0.5 rounded text-pink-600">Formula: (∑ Kyte-Doolittle Hydropathy) / Total Length</code></li>
                
                <li><strong>Instability Index:</strong> Predicts in-vivo half-life and stability. A score below 40 generally indicates in-vitro stability.<br/>
                <code className="text-sm bg-surface-100 px-1 py-0.5 rounded text-pink-600">Formula: II = (10 / L) * ∑ DIWV(x[i], x[i+1]) (Based on dipeptide weight values)</code></li>
                
                <li><strong>Charge_pH7.4 (Net Charge at Physiological pH):</strong> Theoretical net charge in blood (pH 7.4). Extreme values degrade pharmacokinetics, leading to rapid clearance.<br/>
                <code className="text-sm bg-surface-100 px-1 py-0.5 rounded text-pink-600">Formula: Derived via Henderson-Hasselbalch equations.</code></li>
              </ul>
            </div>
          )
        },
        {
          id: 'ptm-liabilities',
          title: 'PTM Liabilities (Chemical Degradation)',
          icon: <Shield className="w-6 h-6 text-rose-500" />,
          body: (
            <div className="space-y-4">
              <p>Post-Translational Modifications (PTMs) and degradation hot spots are identified via regex scanning to warn against chemical liabilities that occur during production, storage, or in-vivo circulation.</p>
              <ul className="list-disc pl-6 space-y-2 text-[15px]">
                <li><strong>N-Glycosylation:</strong> Scans for <code>N-X-S/T</code> motifs (X != P). Unintended N-glycosylation in the variable region causes extreme heterogeneity and can block the paratope. <span className="font-bold text-rose-600">(Flags RED)</span></li>
                <li><strong>Deamidation (NG, NN, NS):</strong> Prone to occur in slightly basic conditions. Asn deamidates into Asp, introducing a negative charge and potential structural distortion. <span className="font-bold text-amber-600">(Flags AMBER)</span></li>
                <li><strong>Isomerization (DG, DS):</strong> Occurs in mildly acidic environments, distorting the peptide backbone. <span className="font-bold text-amber-600">(Flags AMBER)</span></li>
                <li><strong>Acid Cleavage (DP):</strong> The Asp-Pro bond is highly susceptible to hydrolysis under low pH conditions (e.g., Protein A elution). <span className="font-bold text-amber-600">(Flags AMBER)</span></li>
                <li><strong>Oxidation (M, W):</strong> Met and Trp are sensitive to reactive oxygen species or light, significantly reducing shelf life. <span className="font-bold text-amber-600">(Flags AMBER)</span></li>
                <li><strong>Free Cysteines:</strong> If the total number of Cys is odd, an unpaired thiol exists, leading to severe intermolecular cross-linking and aggregation. <span className="font-bold text-rose-600">(Flags RED)</span></li>
              </ul>
            </div>
          )
        },
        {
          id: 'data-dictionary',
          title: 'Output Parameters (Data Dictionary)',
          icon: <TableProperties className="w-6 h-6 text-brand-600" />,
          body: (
            <div className="space-y-4 overflow-x-auto">
              <p>The final comprehensive CSV report encompasses both 3D metrics and 1D sequence evaluations. Below is the data dictionary:</p>
              <table className="w-full text-sm text-left border-collapse border border-surface-200">
                <thead className="bg-surface-50 text-surface-700">
                  <tr>
                    <th className="p-3 border border-surface-200 font-bold">Column</th>
                    <th className="p-3 border border-surface-200 font-bold">Description & Biological Significance</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-surface-200">
                  <tr><td className="p-3 font-mono">Filename</td><td className="p-3">Original PDB/CIF input filename.</td></tr>
                  <tr><td className="p-3 font-mono">Status</td><td className="p-3">'SUCCESS' for successful computation, 'FAILED' for structural errors or pipeline crashes.</td></tr>
                  <tr className="bg-surface-50/50"><td colSpan={2} className="p-3 font-bold text-brand-700">--- 3D Structure Metrics (TAP / TNP) ---</td></tr>
                  <tr><td className="p-3 font-mono">Total CDR Length (L_tot)</td><td className="p-3">Sum of all 6 CDR lengths. Excessive length correlates with low expression and high aggregation.</td></tr>
                  <tr><td className="p-3 font-mono">PSH</td><td className="p-3">Patches of Surface Hydrophobicity. Higher values increase aggregation propensity.</td></tr>
                  <tr><td className="p-3 font-mono">PPC / PNC</td><td className="p-3">Positive/Negative Charge Patches. Extreme charges cause off-target toxicity or viscosity issues.</td></tr>
                  <tr><td className="p-3 font-mono">SFvCSP</td><td className="p-3">Fv Charge Symmetry. Extreme negative values imply severe heavy-light chain charge asymmetry.</td></tr>
                  <tr className="bg-surface-50/50"><td colSpan={2} className="p-3 font-bold text-brand-700">--- 1D Sequence Properties (Physicochemical) ---</td></tr>
                  <tr><td className="p-3 font-mono">VH/VL_Length / MW</td><td className="p-3">Absolute amino acid length and Molecular Weight (Daltons).</td></tr>
                  <tr><td className="p-3 font-mono">VH/VL_pI</td><td className="p-3">Isoelectric Point. Protein net charge is zero here, maximizing precipitation risk.</td></tr>
                  <tr><td className="p-3 font-mono">VH/VL_GRAVY</td><td className="p-3">Grand Average of Hydropathy. High positive values indicate a dangerously hydrophobic sequence.</td></tr>
                  <tr><td className="p-3 font-mono">VH/VL_Instability</td><td className="p-3">Instability Index. &gt;40 indicates reduced in-vitro stability and half-life.</td></tr>
                  <tr><td className="p-3 font-mono">VH/VL_Charge</td><td className="p-3">Net charge at physiological pH (7.4).</td></tr>
                  <tr className="bg-surface-50/50"><td colSpan={2} className="p-3 font-bold text-brand-700">--- PTM Liabilities ---</td></tr>
                  <tr><td className="p-3 font-mono">VH/VL_NGlyc / Sites</td><td className="p-3">N-Glycosylation sites. Unintended variable region glycosylation obscures binding (RED FLAG).</td></tr>
                  <tr><td className="p-3 font-mono">VH/VL_Deamidation</td><td className="p-3">Deamidation hotspots (NG, NN, NS). Occurs in basic pH, introduces negative charge.</td></tr>
                  <tr><td className="p-3 font-mono">VH/VL_Isomerization</td><td className="p-3">Isomerization hotspots (DG, DS). Distorts backbone under acidic conditions.</td></tr>
                  <tr><td className="p-3 font-mono">VH/VL_Cleavage</td><td className="p-3">Acid Cleavage (DP). Prone to hydrolysis during low pH Protein A elution.</td></tr>
                  <tr><td className="p-3 font-mono">VH/VL_Oxidation</td><td className="p-3">Oxidation (M, W). Sensitive to ROS, drastically limits shelf-life.</td></tr>
                  <tr><td className="p-3 font-mono">VH/VL_Cys</td><td className="p-3">Odd counts (e.g. '5 (Free: Yes)') indicate unpaired thiols causing fatal cross-linking (RED FLAG).</td></tr>
                  <tr className="bg-surface-50/50"><td colSpan={2} className="p-3 font-bold text-brand-700">--- System Diagnostics ---</td></tr>
                  <tr><td className="p-3 font-mono">Error Message</td><td className="p-3">If Status is 'FAILED', captures Python stack traces and structural parsing errors.</td></tr>
                </tbody>
              </table>
            </div>
          )
        },
        {
          id: 'architecture',
          title: 'System Architecture & Engines',
          icon: <Cpu className="w-6 h-6 text-surface-600" />,
          body: (
            <div className="space-y-4">
              <p>The platform relies on a distributed computing architecture to handle heavy structural predictions seamlessly.</p>
              <ul className="list-disc pl-6 space-y-4">
                <li><strong>ImmuneBuilder (Deep Learning):</strong> A fast, PyTorch-based neural network model for predicting high-accuracy antibody structures from sequence. It uses ABodyBuilder2 for standard VHVL antibodies and NanoBuilder2 for VHH nanobodies.</li>
                <li><strong>Remote SSH Execution:</strong> The Node.js server securely dispatches commands and transfers fasta/pdb files to the specified remote HPC cluster, enabling the use of GPU nodes without overloading the web frontend.</li>
                <li><strong>TheraSAbDab Synchronization:</strong> The platform relies on the latest clinical antibody data from Oxford OPIG group, recalculating properties and dynamic percentiles.</li>
              </ul>
            </div>
          )
        },
        {
          id: 'tips-tricks',
          title: 'Tips, Tricks & Best Practices',
          icon: <Lightbulb className="w-6 h-6 text-amber-500" />,
          body: (
            <div className="space-y-4">
              <ul className="list-disc pl-6 space-y-2">
                <li><strong>High-Res Image Export:</strong> In the Guidelines tab, click any Box-and-Whisker plot to enlarge it. From the modal, use the "Download High-Res" button to export a 300 DPI PNG suitable for publications.</li>
                <li><strong>Navigating the Data Table:</strong> Columns are color-coded based on the 5-tier system. The ID column is sticky, making horizontal scrolling much easier.</li>
                <li><strong>Excel Reporting:</strong> The exported Excel file uses precise Hex color mapping corresponding to the 5-tier system.</li>
                <li><strong>Sequence Input Formatting:</strong> When uploading a <code>.fasta</code> file for TAP analysis (mAb), ensure the sequences are paired properly (VH and VL).</li>
              </ul>
            </div>
          )
        },
        {
          id: 'changelog',
          title: 'Version History (Changelog)',
          icon: <Layers className="w-6 h-6 text-surface-600" />,
          body: (
            <div className="space-y-4">
              <div className="border-l-2 border-brand-200 pl-4 py-1">
                <h5 className="font-bold text-surface-800">v3.3.0 (Latest)</h5>
                <ul className="list-disc pl-5 mt-2 space-y-1 text-surface-600">
                  <li><strong>Target Filters</strong>: Added new Target filtering dimensions for both TAP and TNP models.</li>
                  <li><strong>Searchable Dropdowns</strong>: Added smart search bars to all multi-select filter dropdowns.</li>
                  <li><strong>Enhanced Reset</strong>: Reset button now completely clears all filter states including Targets and Years.</li>
                </ul>
                <h5 className="font-bold text-surface-800 mt-4">v3.2.5</h5>
                <ul className="list-disc pl-5 mt-2 space-y-1 text-sm">
                  <li><strong>Pipeline Optimization:</strong> Implemented Base64 ZIP memory streaming (using fflate) for bulk uploads, completely eliminating local disk I/O bottlenecks in Node.js.</li>
                  <li><strong>Zero-Copy Downloads:</strong> Built a <code>tar</code> pipeline for bulk result downloads directly from the HPC stdout to the Express HTTP response, preventing OOM crashes.</li>
                  <li><strong>CORS Fix:</strong> Resolved an SVG export failure by enforcing `crossorigin="anonymous"` for external font sheets.</li>
                  <li><strong>TNP Baseline Fix:</strong> Fixed an issue where TNP metrics (e.g., VHH Length, MW, pI) were missing the color-coded baseline evaluations due to a mismatched chain identifier.</li>
                </ul>
              </div>
              <div className="border-l-2 border-surface-200 pl-4 py-1">
                <h5 className="font-bold text-surface-600">v3.2.1</h5>
                <ul className="list-disc pl-5 mt-2 space-y-1 text-sm">
                  <li><strong>Mapping Alignment:</strong> Complete synchronization of TAP/TNP reference thresholds between Python calculation scripts and frontend visualization.</li>
                  <li><strong>Comprehensive Documentation:</strong> Restored and expanded the documentation center to include detailed algorithm parameters, formula logic, and data dictionaries.</li>
                  <li><strong>5-Tier Visual System:</strong> Transitioned from a 3-color to a 5-color evaluation system mapping exactly to 9 statistical percentiles (RED, AMBER, L-GREEN, M-GREEN, D-GREEN).</li>
                  <li><strong>Intelligent UI Rendering:</strong> Completely rebuilt the Box & Whisker plot algorithm with SVG and staggering logic. Added 300 DPI PNG exports.</li>
                </ul>
              </div>
              <div className="border-l-2 border-surface-200 pl-4 py-1">
                <h5 className="font-bold text-surface-600">v3.1.0</h5>
                <ul className="list-disc pl-5 mt-1 space-y-1 text-sm text-surface-500">
                  <li>Patched numeric precision globally to enforce a maximum of 2 decimal places for better readability.</li>
                  <li>Fixed a major bug where <code>VHH</code> chains from TNP arrays were skipped by regex, restoring their visual flags.</li>
                </ul>
              </div>
              <div className="border-l-2 border-surface-200 pl-4 py-1">
                <h5 className="font-bold text-surface-600">v3.0.0</h5>
                <ul className="list-disc pl-5 mt-1 space-y-1 text-sm text-surface-500">
                  <li>Introduced dynamic thresholds via user-provided custom CSV references.</li>
                  <li>Full Excel sync with cell colors based on the 5-tier logic.</li>
                </ul>
              </div>
              <div className="border-l-2 border-surface-200 pl-4 py-1">
                <h5 className="font-bold text-surface-600">v2.0.0</h5>
                <ul className="list-disc pl-5 mt-1 space-y-1 text-sm text-surface-500">
                  <li>Added TNP (Therapeutic Nanobody Profiling) support.</li>
                  <li>Integrated NanoBuilder2 alongside ABodyBuilder2.</li>
                </ul>
              </div>
              <div className="border-l-2 border-surface-200 pl-4 py-1">
                <h5 className="font-bold text-surface-600">v1.0.0</h5>
                <ul className="list-disc pl-5 mt-1 space-y-1 text-sm text-surface-500">
                  <li>Initial platform release: TAP analysis module and SSH cluster integration.</li>
                </ul>
              </div>
            </div>
          )
        }
      ]
    },
    zh: {
      title: '系统文档中心',
      subtitle: 'TAP/TNP 核心指标、5级成药性评估标准与系统架构指南 (v3.3.0)',
      intro: '本平台深度集成了最新版的治疗性抗体分析 (TAP 2024) 和治疗性纳米抗体分析 (TNP 2025) 算法。通过将序列特征与高精度结构预测 (ImmuneBuilder) 相结合，为您提供详尽的成药性打分。版本 3.2.5 引入了基于动态百分位数的 5 级评估基准，并全面恢复了详细的参数公式解读与系统字典。',
      sections: [
        {
          id: 'quick-start',
          title: '快速开始与操作向导',
          icon: <Play className="w-6 h-6 text-brand-600" />,
          body: (
            <div className="space-y-4">
              <p>欢迎使用 TAP/TNP 成药性评估平台。请遵循以下步骤：</p>
              <h4 className="font-bold text-surface-800 mt-4 border-b pb-2">1. 配置服务器连接 (Settings)</h4>
              <ul className="list-decimal pl-4 space-y-2">
                <li>进入 <strong>Settings (设置)</strong> 标签页，填写您的 HPC/服务器 SSH 登录凭证。</li>
                <li>确保 <strong>Remote Base Path (远程根路径)</strong> 和 <strong>Conda Profile</strong> 指向正确。配置完成后，结构建模任务将下发给远端算力集群执行。</li>
              </ul>
              <h4 className="font-bold text-surface-800 mt-4 border-b pb-2">2. 动态基线与自定义参照 (Guidelines)</h4>
              <ul className="list-decimal pl-4 space-y-2">
                <li>在 <strong>Guidelines</strong> 标签中，您可以查看临床验证抗体的数据分布 (箱线图)。</li>
                <li>您可以上传自定义的 CSV 参考数据来覆盖系统默认阈值。<em>注：自定义基线会被持久化保存，直至手动重置。</em></li>
              </ul>
              <h4 className="font-bold text-surface-800 mt-4 border-b pb-2">3. 文件上传与分析执行 (Upload)</h4>
              <ul className="list-decimal pl-4 space-y-2">
                <li>前往 <strong>Upload</strong> 面板上传 <code>.fasta</code>, <code>.pdb</code>, 或 <code>.cif</code> 文件，选择模式 (TAP/TNP)。</li>
                <li>对于序列文件，系统会自动调用 ABodyBuilder2/NanoBuilder2 进行 3D 建模。点击 <em>Run Pipeline</em> 提交异步任务。</li>
              </ul>
              <h4 className="font-bold text-surface-800 mt-4 border-b pb-2">4. 结果查看与导出 (Results)</h4>
              <ul className="list-decimal pl-4 space-y-2">
                <li>在 <strong>Tasks</strong> 面板监控 SSH 日志。完成后点击 <strong>View Results</strong>。</li>
                <li>点击右上角的 <strong>Export to Excel</strong> 可将带有 5 级色彩标签的数据下载为精美的 Excel 报表。</li>
              </ul>
            </div>
          )
        },
        {
          id: '5-tier-system',
          title: '全新的 5 级颜色评估体系',
          icon: <Sparkles className="w-6 h-6 text-emerald-600" />,
          body: (
            <div className="space-y-4">
              <p>v3.3.0 从“红黄绿”3色系统升级为基于 TheraSAbDab 的 <strong>5 级精细色彩评估体系</strong>：</p>
              <ul className="list-none space-y-4 mt-4">
                <li className="flex items-start gap-3">
                  <div className="mt-1 flex-shrink-0"><span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-rose-500 text-white font-bold text-[10px] uppercase border border-rose-600 shadow-sm">RED (红区)</span></div>
                  <div><strong>极端风险：</strong> 属性落入临床药物范围外 (&lt;0% 或 &gt;100% 分位)。代表严重成药性缺陷 (如极易聚集、高粘度)。</div>
                </li>
                <li className="flex items-start gap-3">
                  <div className="mt-1 flex-shrink-0"><span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-amber-400 text-amber-950 font-bold text-[10px] uppercase border border-amber-500 shadow-sm">AMBER (黄区)</span></div>
                  <div><strong>高风险预警：</strong> 处于极度边缘区 (0-5% 或 95-100%)。需重点进行序列工程改造或依赖特殊制剂工艺。</div>
                </li>
                <li className="flex items-start gap-3">
                  <div className="mt-1 flex-shrink-0"><span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-emerald-200 text-emerald-950 font-bold text-[10px] uppercase border border-emerald-300 shadow-sm">L-GREEN (浅绿)</span></div>
                  <div><strong>边缘风险：</strong> 处于 5-10% 或 90-95% 区间。在可接受范围内，但略偏离临床常规设计。</div>
                </li>
                <li className="flex items-start gap-3">
                  <div className="mt-1 flex-shrink-0"><span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-emerald-400 text-emerald-950 font-bold text-[10px] uppercase border border-emerald-500 shadow-sm">M-GREEN (中绿)</span></div>
                  <div><strong>标准区间：</strong> 处于 10-25% 或 75-90% 区间。表现良好，安全性较高。</div>
                </li>
                <li className="flex items-start gap-3">
                  <div className="mt-1 flex-shrink-0"><span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-emerald-600 text-white font-bold text-[10px] uppercase border border-emerald-700 shadow-sm">D-GREEN (深绿)</span></div>
                  <div><strong>核心最优区：</strong> 完美落入中间 25-75% 四分位核心区 (IQR)。代表最安全、最稳健的理化性质。</div>
                </li>
              </ul>
              <p className="mt-4">5 级评估已实现网页表格、SVG 箱线图和 Excel 表格的 100% 同步渲染。</p>
            </div>
          )
        },
        {
          id: 'algo-details',
          title: '算法解析与核心结构指标',
          icon: <Activity className="w-6 h-6 text-brand-600" />,
          body: (
            <div className="space-y-4">
              <p>引擎通过分析三维结构，预测并筛除开发早期的成药性风险。<strong>注：你可以在 Guidelines 页面配置分析引擎使用的风险阈值和属性百分位数。这直接决定 RAG 标签的判定标准。</strong></p>
              
              <h4 className="font-bold text-surface-800 border-b pb-2 mt-4">TAP 2024 Guidelines (结构评估 - 传统抗体)</h4>
              <p className="text-[15px] text-surface-600">基准阈值源自分析 664 个临床一期以上治疗性抗体 (CSTs) 数据集 (Communications Biology, 2024)。</p>
              <ul className="list-none space-y-4 text-[15px]">
                <li>
                  <strong>L_tot (总 CDR 长度):</strong> 依据 IMGT 编号规则计算 6 个 CDR 区域氨基酸总长度。过长的 CDR 环极易导致高度构象柔性和聚集。<br/>
                  <code className="text-sm bg-surface-100 px-1 py-0.5 rounded text-pink-600">计算公式: L_tot = ∑ Length(CDR_i) (其中 i 包含 H1, H2, H3, L1, L2, L3)</code><br/>
                  <span className="text-sm text-surface-500">参考范围 (氨基酸数)：绿区 (42-55)，黄区 (37-42 & 55-63)，红区 (&lt;37 & &gt;63)。</span>
                </li>
                <li>
                  <strong>PSH (表面疏水斑块):</strong> 结合 Kyte-Doolittle 疏水量表和 Shrake-Rupley 溶剂可及表面积 (1.4Å 探针) 计算得出。过高的 PSH 会极大增加分子间疏水相互作用，导致聚集。<br/>
                  <code className="text-sm bg-surface-100 px-1 py-0.5 rounded text-pink-600">计算公式: PSH = ∑ (SASA_i * Kyte-Doolittle_i) (仅计算表面暴露疏水残基)</code><br/>
                  <span className="text-sm text-surface-500">参考范围：绿区 (110.11-168.06)，黄区 (95.58-110.11 & 168.06-201.59)，红区 (&lt;95.58 & &gt;201.59)。</span>
                </li>
                <li>
                  <strong>PPC & PNC (表面正/负电荷斑块):</strong> 量化 CDR 及其邻近表面的电荷斑块聚集程度。极高的表面净电荷容易导致非特异性结合 (组织交叉反应) 及体内快速清除。<br/>
                  <span className="text-sm text-surface-500">PPC 范围：绿区 (≤ 1.32)，黄区 (1.32-4.22)，红区 (&gt; 4.22)。PNC 范围：绿区 (≤ 2.00)，黄区 (2.00-4.42)，红区 (&gt; 4.42)。</span>
                </li>
                <li>
                  <strong>SFvCSP (Fv 结构电荷对称性):</strong> 评估重链与轻链之间的电荷分布对称性。极端的负值表示高度不对称，会导致溶解度降低。<br/>
                  <code className="text-sm bg-surface-100 px-1 py-0.5 rounded text-pink-600">简化逻辑: 综合考量 Q_H (重链净电荷) 与 Q_L (轻链净电荷) 乘积并对接触面积归一化。</code><br/>
                  <span className="text-sm text-surface-500">参考范围：绿区 (&gt; -6.00)，黄区 (-30.60 至 -6.00)，红区 (&lt; -30.60)。</span>
                </li>
              </ul>
              
              <h4 className="font-bold text-surface-800 border-b pb-2 mt-6">TNP 2025 Guidelines (结构评估 - 纳米抗体/VHH)</h4>
              <p className="text-[15px] text-surface-600">在 TAP 基础上专为单域抗体定制，充分考虑了纳米抗体特有的长 CDR3 环和暴露的 FR2 框架四联体残基 (基准源自 36 个临床纳米抗体, bioRxiv, 2025)。</p>
              <ul className="list-none space-y-4 text-[15px]">
                <li>
                  <strong>L (Total CDR Length) & L3 (CDR3 长度):</strong> 纳米抗体往往依赖更长的 CDR3 环伸入抗原凹陷表位。<br/>
                  <span className="text-sm text-surface-500">L 范围：绿区 (24-37.25)，红区 (&lt;20 & &gt;39)。L3 范围：绿区 (8-21.25)，红区 (&lt;5 & &gt;23)。</span>
                </li>
                <li>
                  <strong>C (CDR3 紧凑度):</strong> 新引入指标，定义为 CDR3 环偏离可变区的“结构跨度”除以其长度。具有双峰分布特征：高紧凑度代表环向后折叠贴在 FR2 区域 (屏蔽了疏水性)，低紧凑度代表环笔直向外延伸。<br/>
                  <code className="text-sm bg-surface-100 px-1 py-0.5 rounded text-pink-600">计算公式: Compactness = (最大欧几里得距离) / L3长度</code><br/>
                  <span className="text-sm text-surface-500">参考范围：绿区 (0.81-1.57)，黄区 (0.56-0.81 & 1.57-1.61)，红区 (&lt;0.56 & &gt;1.61)。</span>
                </li>
                <li>
                  <strong>PSH (表面疏水斑块):</strong> 针对纳米抗体暴露 FR2 四联体的独特表面形态进行了阈值调优适配。<br/>
                  <span className="text-sm text-surface-500">参考范围：绿区 (79.59-126.83)，黄区 (73.40-79.59 & 126.83-155.47)，红区 (&lt;73.40 & &gt;155.47)。</span>
                </li>
                <li>
                  <strong>PPC & PNC:</strong> 评估 VHH 单域表面的电荷斑块风险。<br/>
                  <span className="text-sm text-surface-500">PPC：绿区 (≤ 0.39)，红区 (&gt; 1.18)。PNC：绿区 (≤ 1.47)，红区 (&gt; 1.88)。</span>
                </li>
              </ul>
            </div>
          )
        },
        {
          id: 'seq-properties',
          title: 'Sequence Properties (理化性质及公式计算)',
          icon: <List className="w-6 h-6 text-brand-600" />,
          body: (
            <div className="space-y-4">
              <p>理化性质基于 Biopython/ProtParam 标准算法计算。计算结果由后台动态地与临床抗体数据库 TheraSAbDab 建立基准比对 (VHVL N=1103, VHH N=28)。判定边界严格遵循该库中的第 5 百分位 (p5) 与第 95 百分位 (p95) 法则。</p>
              <ul className="list-disc pl-6 space-y-3 text-[15px]">
                <li><strong>pI (等电点):</strong> 决定了蛋白质在该 pH 值环境时净电荷为零，此时分子间斥力最小，极易沉淀/聚集。制剂配方的 pH 值应尽量避开 pI。<br/>
                <code className="text-sm bg-surface-100 px-1 py-0.5 rounded text-pink-600">计算逻辑: 采用 Bjellqvist pK 游离常数表 (侧链 K,R,H,D,E,C,Y 及首尾)，利用牛顿迭代法寻找 Z = 0 时的 pH。</code></li>
                
                <li><strong>GRAVY (平均亲疏水性总和):</strong> 正值表明整体倾向疏水，异常高的正值代表极易聚集成团。<br/>
                <code className="text-sm bg-surface-100 px-1 py-0.5 rounded text-pink-600">计算公式: GRAVY = ( ∑ Kyte-Doolittle 残基疏水值 ) / 序列总长度</code></li>
                
                <li><strong>Instability Index (不稳定指数):</strong> 预测蛋白质在体内的半衰期和稳定性。得分小于 40 通常代表该蛋白在体外是稳定的。<br/>
                <code className="text-sm bg-surface-100 px-1 py-0.5 rounded text-pink-600">计算公式: II = (10 / L) * ∑ DIWV(x[i], x[i+1]) (分析二肽组合 DIWV 权重表)</code></li>
                
                <li><strong>Charge_pH7.4 (生理条件下的净电荷):</strong> 计算血液生理环境 (pH 7.4) 下的理论净电荷量。极端的净电荷会导致药代动力学恶化及快速清除。<br/>
                <code className="text-sm bg-surface-100 px-1 py-0.5 rounded text-pink-600">计算公式: Z = ∑ (N_i / (1 + 10^(pH - pKa_i))) - ∑ (N_j / (1 + 10^(pKa_j - pH))) (Henderson-Hasselbalch)</code></li>
              </ul>
            </div>
          )
        },
        {
          id: 'ptm-liabilities',
          title: 'PTM Liabilities (化学降解热点)',
          icon: <Shield className="w-6 h-6 text-rose-500" />,
          body: (
            <div className="space-y-4">
              <p>翻译后修饰 (PTM) 与降解热点是在抗体序列级别进行正则扫描，警示可能在生产、纯化或体内循环中发生的化学变异。任何命中结果都将在面板中以黄灯 (AMBER) 或红灯 (RED) 标记。</p>
              <ul className="list-disc pl-6 space-y-2 text-[15px]">
                <li><strong>N-Glycosylation (N-糖基化):</strong> 扫描 <code>N-X-S/T</code> 基序 (X不为P)。可变区意外的 N-糖基化会导致极大的异质性，甚至阻碍抗原结合。 <span className="font-bold text-rose-600">(一旦发现即亮红灯)</span></li>
                <li><strong>Deamidation (脱酰胺 - NG, NN, NS):</strong> 弱碱性环境下极易发生。生成天冬氨酸或异天冬氨酸，引入额外负电荷，破坏构象。 <span className="font-bold text-amber-600">(标为 AMBER)</span></li>
                <li><strong>Isomerization (异构化 - DG, DS):</strong> 弱酸性环境下极易发生，导致肽键骨架结构扭曲。 <span className="font-bold text-amber-600">(标为 AMBER)</span></li>
                <li><strong>Acid Cleavage (酸裂解 - DP):</strong> 天冬氨酸-脯氨酸键在低 pH 条件下 (如 Protein A 洗脱) 极易水解断裂。 <span className="font-bold text-amber-600">(标为 AMBER)</span></li>
                <li><strong>Oxidation (氧化 - M, W):</strong> 易被活性氧自由基或光照氧化，导致货架期降低。 <span className="font-bold text-amber-600">(标为 AMBER)</span></li>
                <li><strong>Free Cysteines (游离半胱氨酸):</strong> 序列中半胱氨酸 (C) 总数为奇数时，提示存在无法配对的游离巯基，将导致严重的分子间交联聚集。 <span className="font-bold text-rose-600">(一旦发现即亮红灯)</span></li>
              </ul>
            </div>
          )
        },
        {
          id: 'data-dictionary',
          title: '输出参数全解 (Data Dictionary)',
          icon: <TableProperties className="w-6 h-6 text-brand-600" />,
          body: (
            <div className="space-y-4 overflow-x-auto">
              <p>系统会生成包含 3D 结构测算和 1D 序列评估的综合性 CSV 报表。以下是表格中输出参数的详细解释与生物学意义：</p>
              <table className="w-full text-sm text-left border-collapse border border-surface-200">
                <thead className="bg-surface-50 text-surface-700">
                  <tr>
                    <th className="p-3 border border-surface-200 font-bold whitespace-nowrap">参数名称 (Column)</th>
                    <th className="p-3 border border-surface-200 font-bold">详细解释与生物学意义 (Description)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-surface-200">
                  <tr><td className="p-3 font-mono text-surface-700">Filename</td><td className="p-3">原始输入的 PDB/CIF 结构文件名。</td></tr>
                  <tr><td className="p-3 font-mono text-surface-700">Status</td><td className="p-3">执行状态。'SUCCESS' 代表完成，'FAILED' 代表结构残缺或运算崩溃。</td></tr>
                  <tr className="bg-surface-50/50"><td colSpan={2} className="p-3 font-bold text-brand-700">--- 3D 结构成药性指标 (TAP / TNP) ---</td></tr>
                  <tr><td className="p-3 font-mono text-surface-700">Total CDR Length (L_tot)</td><td className="p-3">所有 6 个 CDR 环的长度总和 (基于 IMGT)。过长的环伴随表达量低和高聚集风险。</td></tr>
                  <tr><td className="p-3 font-mono text-surface-700">PSH</td><td className="p-3">表面疏水斑块积分。值越高，抗体疏水聚集倾向越严重。</td></tr>
                  <tr><td className="p-3 font-mono text-surface-700">PPC / PNC</td><td className="p-3">表面正/负电荷斑块积分。极端的电荷导致非特异性结合 (脱靶毒性) 及体内快速清除。</td></tr>
                  <tr><td className="p-3 font-mono text-surface-700">SFvCSP</td><td className="p-3">Fv 电荷对称性参数。极端负值意味重轻链界面电荷严重不对称，大幅降低溶解度。</td></tr>
                  <tr className="bg-surface-50/50"><td colSpan={2} className="p-3 font-bold text-brand-700">--- 1D 序列理化性质 (Physicochemical) ---</td></tr>
                  <tr><td className="p-3 font-mono text-surface-700">VH/VL_Length / MW</td><td className="p-3">重链 (VH) 或轻链 (VL) 的氨基酸绝对长度及分子量 (Daltons)。</td></tr>
                  <tr><td className="p-3 font-mono text-surface-700">VH/VL_pI</td><td className="p-3">等电点 (Isoelectric Point)。在该 pH 下蛋白质净电荷为零，极易沉淀。制剂缓冲液需避开。</td></tr>
                  <tr><td className="p-3 font-mono text-surface-700">VH/VL_GRAVY</td><td className="p-3">总平均亲疏水性指数。极端的正值提示序列整体过度疏水。</td></tr>
                  <tr><td className="p-3 font-mono text-surface-700">VH/VL_Instability</td><td className="p-3">不稳定指数 (Instability Index)。大于 40 提示蛋白在体外不稳定，半衰期受损。</td></tr>
                  <tr><td className="p-3 font-mono text-surface-700">VH/VL_Charge</td><td className="p-3">生理条件 (pH 7.4) 下的净电荷。</td></tr>
                  <tr className="bg-surface-50/50"><td colSpan={2} className="p-3 font-bold text-brand-700">--- PTM 化学降解热点 (Liabilities) ---</td></tr>
                  <tr><td className="p-3 font-mono text-surface-700">VH/VL_NGlyc / Sites</td><td className="p-3">N-糖基化位点数量与位置。抗体可变区的意外糖基化会引发剧烈异质性 (直接亮红灯)。</td></tr>
                  <tr><td className="p-3 font-mono text-surface-700">VH/VL_Deamidation</td><td className="p-3">脱酰胺热点位置 (NG, NN, NS)。弱碱环境下极易发生，引入额外负电荷。</td></tr>
                  <tr><td className="p-3 font-mono text-surface-700">VH/VL_Isomerization</td><td className="p-3">异构化热点位置 (DG, DS)。弱酸环境下发生，导致多肽骨架扭曲。</td></tr>
                  <tr><td className="p-3 font-mono text-surface-700">VH/VL_Cleavage</td><td className="p-3">酸裂解热点位置 (DP)。在 Protein A 低 pH 洗脱步骤中极易发生主链断裂。</td></tr>
                  <tr><td className="p-3 font-mono text-surface-700">VH/VL_Oxidation</td><td className="p-3">氧化热点位置 (M, W)。极易受活性氧影响变质，降低货架期。</td></tr>
                  <tr><td className="p-3 font-mono text-surface-700">VH/VL_Cys</td><td className="p-3">游离半胱氨酸状态。示例：'5 (Free: Yes)' 奇数代表存在无法配对的游离巯基，将引发致命的交联聚集 (直接亮红灯)。</td></tr>
                  <tr className="bg-surface-50/50"><td colSpan={2} className="p-3 font-bold text-brand-700">--- 系统运行诊断 ---</td></tr>
                  <tr><td className="p-3 font-mono text-surface-700">Error Message</td><td className="p-3">如果 Status 为 FAILED，此列将精确捕获并输出 Python 底层崩溃堆栈与错误原因。</td></tr>
                </tbody>
              </table>
            </div>
          )
        },
        {
          id: 'architecture',
          title: '系统架构设计',
          icon: <Cpu className="w-6 h-6 text-surface-600" />,
          body: (
            <div className="space-y-4">
              <p>平台采用前后端分离并与远端集群相结合的分布式调度架构：</p>
              <ul className="list-disc pl-6 space-y-4">
                <li><strong>ImmuneBuilder (深度学习预测核心):</strong> 基于 PyTorch 的高精度模型。常规抗体使用 ABodyBuilder2，纳米抗体使用 NanoBuilder2。</li>
                <li><strong>SSH 异步执行引擎:</strong> 后端 Node.js 服务器通过 SSH 安全下发任务至 HPC，利用集群算力彻底避免前端崩溃。</li>
                <li><strong>TheraSAbDab 动态数据同步:</strong> 平台以临床抗体大数据库为知识底座，动态计算分位数提供先进的科学参考。</li>
              </ul>
            </div>
          )
        },
        {
          id: 'tips-tricks',
          title: '使用指导、技巧与最佳实践',
          icon: <Lightbulb className="w-6 h-6 text-amber-500" />,
          body: (
            <div className="space-y-4">
              <ul className="list-disc pl-6 space-y-2">
                <li><strong>导出高清配图：</strong> 在 <strong>Guidelines</strong> 面板中点击任意箱线图可全屏放大。点击 <strong>"Download High-Res"</strong> 可将 SVG 转为 300 DPI 纯净 PNG，适合学术论文或组会 PPT。</li>
                <li><strong>数据表水平滚动的技巧：</strong> 查看 Results 矩阵时，第一列 ID 已经吸附冻结 (Sticky)，可安心横向滚动查看庞杂指标。</li>
                <li><strong>快速生成 Excel 报告：</strong> 导出的 Excel 经过底层渲染重写，会自动带有对应 5色分级的 HEX 背景填充及加粗字体。</li>
                <li><strong>双链抗体的 FASTA 编写规范：</strong> 对于常规抗体的 TAP 分析，请确保 <code>.fasta</code> 序列完整包含了 VH 和 VL 链，以正确折叠 Fv 结构。</li>
              </ul>
            </div>
          )
        },
        {
          id: 'changelog',
          title: '系统版本与更新记录 (Changelog)',
          icon: <Layers className="w-6 h-6 text-surface-600" />,
          body: (
            <div className="space-y-4">
              <div className="border-l-2 border-brand-200 pl-4 py-1">
                <h5 className="font-bold text-surface-800">v3.3.0 (当前最新版)</h5>
                <ul className="list-disc pl-5 mt-2 space-y-1 text-surface-600">
                  <li><strong>靶点过滤 (Target Filters)</strong>: 为 TAP 和 TNP 数据集新增了基于 Target 的数据检索与过滤。</li>
                  <li><strong>下拉搜索 (Searchable Dropdowns)</strong>: 为所有多选过滤器（临床阶段、年份、靶点）内置了实时智能搜索框。</li>
                  <li><strong>彻底重置 (Enhanced Reset)</strong>: 修复了 Reset 按钮无法清除部分新增过滤维度状态的问题，实现全局一键重置。</li>
                </ul>
                <h5 className="font-bold text-surface-800 mt-4">v3.2.5</h5>
                <ul className="list-disc pl-5 mt-2 space-y-1 text-sm">
                  <li><strong>上传性能优化：</strong> 引入 <code>fflate</code> 实现纯前端内存打包，Base64 流式直传 SSH，彻底消除 Node.js 磁盘写入瓶颈。</li>
                  <li><strong>海量下载重构：</strong> 构建零拷贝管道，利用远端集群动态 <code>tar</code> 打包，将标准输出直连 HTTP 响应流，防止大文件 OOM 崩溃。</li>
                  <li><strong>跨域字体修复：</strong> 修复了导出高清图片时由于请求外部字体样式表触发的跨域 <code>CORS</code> 阻塞问题。</li>
                  <li><strong>TNP 基线色彩修复：</strong> 修复了因链标识符不匹配导致 TNP 指标（如 VHH Length、MW、pI 等）无法正确加载统计基准及颜色评估的问题。</li>
                </ul>
              </div>
              <div className="border-l-2 border-surface-200 pl-4 py-1">
                <h5 className="font-bold text-surface-600">v3.2.1</h5>
                <ul className="list-disc pl-5 mt-2 space-y-1 text-sm">
                  <li><strong>映射对齐与复核：</strong> 全面深度修复与复核了底层 Python 计算基准与前端视觉呈现之间的参考值同步 (涵盖 TAP 与 TNP)。</li>
                  <li><strong>文档全面扩充：</strong> 全面恢复并丰富了系统文档，包含了详尽的算法介绍、参数阈值解读以及输出字典向导。</li>
                  <li><strong>5级视觉体系：</strong> 升级为严格对应 9个统计学分位数的 5色系统 (RED, AMBER, L-GREEN, M-GREEN, D-GREEN)。</li>
                  <li><strong>智能图表渲染：</strong> 彻底重构 SVG 箱线图渲染，加入标签错位算法，支持无损高清出图 (300 DPI PNG)。</li>
                </ul>
              </div>
              <div className="border-l-2 border-surface-200 pl-4 py-1">
                <h5 className="font-bold text-surface-600">v3.1.0</h5>
                <ul className="list-disc pl-5 mt-1 space-y-1 text-sm text-surface-500">
                  <li>全局修复数值精度问题，特征维度均强制截断保留最多2位小数，极大提升了图表可读性。</li>
                  <li>修复了前端正则不匹配 <code>VHH</code> 导致 TNP 纳米抗体评估标志(Flag) 无法正常渲染的重大 Bug。</li>
                </ul>
              </div>
              <div className="border-l-2 border-surface-200 pl-4 py-1">
                <h5 className="font-bold text-surface-600">v3.0.0</h5>
                <ul className="list-disc pl-5 mt-1 space-y-1 text-sm text-surface-500">
                  <li>上线了“动态基线”系统，允许用户上传自定义的参考数据集，并实现持久化。</li>
                  <li>重置并优化了 Excel 导出逻辑，将 5 级颜色直接写入导出的表格背景中。</li>
                </ul>
              </div>
              <div className="border-l-2 border-surface-200 pl-4 py-1">
                <h5 className="font-bold text-surface-600">v2.0.0</h5>
                <ul className="list-disc pl-5 mt-1 space-y-1 text-sm text-surface-500">
                  <li>新增针对单域抗体(Nanobody)的 TNP (Therapeutic Nanobody Profiling) 模块。</li>
                  <li>加入 NanoBuilder2 三维结构计算支持。</li>
                </ul>
              </div>
              <div className="border-l-2 border-surface-200 pl-4 py-1">
                <h5 className="font-bold text-surface-600">v1.0.0</h5>
                <ul className="list-disc pl-5 mt-1 space-y-1 text-sm text-surface-500">
                  <li>平台初创版本发布：实现了基础的 TAP 成药性评估与 HPC SSH 异步计算框架。</li>
                </ul>
              </div>
            </div>
          )
        }
      ]
    }
  };

  const t = content[lang];

  return (
    <div className="max-w-5xl mx-auto p-4 sm:p-6 lg:p-8 space-y-8 pb-32 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-surface-800 flex items-center gap-3 font-display">
            <BookOpen className="w-8 h-8 text-brand-600" />
            Platform Documentation
          </h1>
          <p className="text-surface-500 font-medium mt-1">Version 3.3.0 Guidelines & Release Notes</p>
        </div>
        <div className="flex bg-surface-100 p-1 rounded-lg border border-surface-200 shadow-sm self-start sm:self-auto">
          <button 
            onClick={() => setLang('en')} 
            className={`px-3 py-1.5 text-sm font-bold rounded-md transition-colors ${lang === 'en' ? 'bg-brand-50 text-brand-700' : 'text-surface-500 hover:text-surface-700'}`}
          >
            English
          </button>
          <button 
            onClick={() => setLang('zh')} 
            className={`px-3 py-1.5 text-sm font-bold rounded-md transition-colors ${lang === 'zh' ? 'bg-brand-50 text-brand-700' : 'text-surface-500 hover:text-surface-700'}`}
          >
            中文
          </button>
        </div>
      </div>

      <header className="bg-white border border-surface-200 rounded-2xl p-10 shadow-sm relative overflow-hidden">
        <div className="relative z-10">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-14 h-14 bg-brand-50 rounded-xl flex items-center justify-center border border-brand-100">
              <BookOpen className="w-7 h-7 text-brand-600" />
            </div>
            <span className="bg-brand-100 text-brand-700 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-widest border border-brand-200 font-mono">v3.3.0</span>
          </div>
          <h1 className="text-3xl md:text-4xl font-extrabold text-surface-900 tracking-tight mb-3 font-display">{t.title}</h1>
          <p className="text-brand-600 text-lg md:text-xl font-bold mb-4 max-w-2xl">{t.subtitle}</p>
          <p className="text-surface-600 max-w-4xl leading-relaxed text-sm md:text-base">{t.intro}</p>
        </div>
      </header>

      <div className="space-y-6">
        {t.sections.map((sec) => (
          <div key={sec.id} className="bg-white rounded-2xl p-8 border border-surface-200 shadow-sm hover:shadow-md transition-shadow relative overflow-hidden">
            <div className="absolute top-0 right-0 p-8 opacity-5 pointer-events-none">
              {sec.icon}
            </div>
            <div className="flex items-center gap-3 mb-6 relative z-10">
              <div className="w-12 h-12 rounded-xl bg-surface-50 flex items-center justify-center border border-surface-100 shadow-sm">
                {sec.icon}
              </div>
              <h2 className="text-xl md:text-2xl font-bold text-surface-900 font-display">{sec.title}</h2>
            </div>
            <div className="text-surface-600 leading-relaxed text-[15px] relative z-10 font-sans">
              {sec.body}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
