import React, { useState, useEffect } from 'react';
import ResultsViewer from './ResultsViewer';
import { BarChart3, CheckCircle2, Clock, PlayCircle, AlertTriangle, Loader2, XCircle, Trash2, WifiOff, ChevronLeft, ChevronRight, Layers, FileArchive, FileText } from 'lucide-react';
import { JobBatch, TargetStatus } from '../types';

interface TasksProps {
  sshConnected: boolean;
  remoteBasePath: string;
}

export default function Tasks({ sshConnected, remoteBasePath }: TasksProps) {
  const [batches, setBatches] = useState<JobBatch[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);
  const [confirmBatchAction, setConfirmBatchAction] = useState<{ id: string, action: 'cancel' | 'delete' } | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [viewingResultsFor, setViewingResultsFor] = useState<string | null>(null);
  const RECORDS_PER_PAGE = 50;

  const fetchJobs = async () => {
    if (!sshConnected) return;
    try {
      setLoading(true);
      const res = await fetch('/api/jobs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ remoteBasePath })
      });
      const data = await res.json();
      if (!res.ok) {
        if (!data.error?.includes('SSH Client is not connected') && !data.error?.includes('SSH Config is missing')) {
          throw new Error(data.error || 'Failed to fetch jobs');
        }
      } else {
        setBatches(Array.isArray(data) ? data : []);
      }
      setError(null);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchJobs();
    const interval = setInterval(fetchJobs, 15000);
    return () => clearInterval(interval);
  }, [sshConnected]);

  const handleCancelTarget = async (batchId: string, targetName: string) => {
    try {
      
      await fetch(`/api/jobs/${batchId}/cancel/${encodeURIComponent(targetName)}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ remoteBasePath }) });
      fetchJobs();
    } catch (err) {}
  };

  const handleDeleteTarget = async (batchId: string, targetName: string) => {
    try {
      
      await fetch(`/api/jobs/${batchId}/delete/${encodeURIComponent(targetName)}`, { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ remoteBasePath }) });
      setConfirmDelete(null);
      fetchJobs();
    } catch (err) {}
  };

  const handleBatchCancel = async (batchId: string) => {
    try {
      
      await fetch(`/api/jobs/${batchId}/cancel`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ remoteBasePath }) });
      setConfirmBatchAction(null);
      fetchJobs();
    } catch (err) {}
  };

  const handleBatchDelete = async (batchId: string) => {
    try {
      
      await fetch(`/api/jobs/${batchId}/delete`, { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ remoteBasePath }) });
      setConfirmBatchAction(null);
      fetchJobs();
    } catch (err) {}
  };

  // Flatten records for pagination
  type FlattenedRecord = TargetStatus & { batchId: string };
  const allRecords: FlattenedRecord[] = (batches || []).flatMap(b => (b.targets || []).map(t => ({ ...t, batchId: b.id })));
  const totalPages = Math.max(1, Math.ceil(allRecords.length / RECORDS_PER_PAGE));
  const currentRecords = allRecords.slice((currentPage - 1) * RECORDS_PER_PAGE, currentPage * RECORDS_PER_PAGE);

  // Re-group current records by batch to display them nicely
  const groupedRecords = currentRecords.reduce((acc, record) => {
    if (!acc[record.batchId]) acc[record.batchId] = [];
    acc[record.batchId].push(record);
    return acc;
  }, {} as Record<string, FlattenedRecord[]>);

  const StatusBadge = ({ status }: { status: TargetStatus['status'] | string }) => {
    const config = {
      'Completed': { icon: CheckCircle2, color: 'text-emerald-700', bg: 'bg-emerald-50 border-emerald-200' },
      'Running': { icon: PlayCircle, color: 'text-blue-700', bg: 'bg-blue-50 border-blue-200' },
      'Predicting': { icon: PlayCircle, color: 'text-brand-700', bg: 'bg-brand-50 border-brand-200' },
      'Preprocessing': { icon: PlayCircle, color: 'text-brand-700', bg: 'bg-brand-50 border-brand-200' },
      'Pending Fold': { icon: Clock, color: 'text-amber-700', bg: 'bg-amber-50 border-amber-200' },
      'Pending MSA': { icon: Clock, color: 'text-amber-700', bg: 'bg-amber-50 border-amber-200' },
      'Failed/Unknown': { icon: AlertTriangle, color: 'text-rose-700', bg: 'bg-rose-50 border-rose-200' },
      'Failed/Stopped': { icon: AlertTriangle, color: 'text-rose-700', bg: 'bg-rose-50 border-rose-200' },
    }[status as string] || { icon: Clock, color: 'text-surface-700', bg: 'bg-surface-50 border-surface-200' };

    const Icon = config.icon;
    return (
      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-bold tracking-wide uppercase border shadow-sm ${config.bg} ${config.color}`}>
        <Icon className="w-3.5 h-3.5" />
        {status}
      </span>
    );
  };

  if (!sshConnected) {
    return (
      <div className="p-12 text-center text-surface-500 bg-white border border-surface-200 rounded-2xl shadow-sm max-w-2xl mx-auto mt-10">
        <WifiOff className="w-12 h-12 mx-auto mb-4 text-surface-300" />
        <h3 className="text-xl font-bold text-surface-900 mb-2 font-display">Cluster Not Connected</h3>
        <p className="text-sm">Please connect to your HPC cluster via SSH in the Dashboard or Settings to view your tasks and results.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-6xl mx-auto animate-in fade-in slide-in-from-bottom-2 duration-300">
      <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-surface-900 font-display">Task Queue & Results</h2>
          <p className="text-sm text-surface-500 mt-1">Manage batches and monitor cluster progress.</p>
        </div>
        <button 
          onClick={fetchJobs} 
          disabled={loading || !sshConnected}
          className="inline-flex items-center gap-2 bg-white border border-surface-200 hover:bg-surface-50 text-surface-700 py-2 px-4 rounded-lg text-sm font-semibold transition-colors shadow-sm self-start sm:self-auto disabled:opacity-50"
        >
          {loading ? <Loader2 className="w-4 h-4 animate-spin text-brand-600" /> : <Clock className="w-4 h-4 text-surface-400" />}
          Refresh List
        </button>
      </header>

      {error && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-sm flex items-start gap-3 animate-in fade-in slide-in-from-top-2">
          <AlertTriangle className="w-5 h-5 shrink-0" />
          <p>{error}</p>
        </div>
      )}

      {Object.keys(groupedRecords).length === 0 ? (
        <div className="bg-white border border-surface-200 rounded-2xl p-12 text-center shadow-sm">
          <div className="flex flex-col items-center justify-center text-surface-400">
            <CheckCircle2 className="w-8 h-8 mb-3 opacity-20" />
            <p className="text-sm font-medium text-surface-500">No active or recent jobs found</p>
            <p className="text-xs mt-1">Submit a new task from the Dashboard to get started</p>
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          {Object.entries(groupedRecords).map(([batchId, records]) => (
            <div key={batchId} className="bg-white border border-surface-200 rounded-2xl overflow-hidden shadow-sm flex flex-col">
              <div className="p-4 border-b border-surface-100 bg-surface-50 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-brand-100 text-brand-600 rounded-lg flex items-center justify-center">
                    <Layers className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-surface-900">Batch ID: <span className="font-mono text-sm ml-1 text-surface-600 font-normal">{batchId}</span></h3>
                    <p className="text-xs font-medium text-surface-500 mt-0.5">{records.length} target{records.length !== 1 ? 's' : ''} shown</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  <div className="hidden sm:flex items-center gap-1 bg-white border border-surface-200 rounded-lg p-0.5 shadow-sm mr-2">
                    
                    <button 
                      onClick={() => setViewingResultsFor(batchId)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 hover:bg-surface-50 text-brand-600 rounded-md text-xs font-bold transition-colors"
                      title="View Profiling Results"
                    >
                      <BarChart3 className="w-3.5 h-3.5" />
                      View Analysis
                    </button>
                    <div className="w-px h-4 bg-surface-200"></div>

                    <a 
                      href={`/api/jobs/${batchId}/download?type=all&remoteBasePath=${encodeURIComponent(remoteBasePath)}`}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 hover:bg-surface-50 text-surface-600 rounded-md text-xs font-semibold transition-colors"
                      title="Download All Files"
                    >
                      <FileArchive className="w-3.5 h-3.5" />
                      All Files (.tar.gz)
                    </a>
                    <div className="w-px h-4 bg-surface-200"></div>
                    <a 
                      href={`/api/jobs/${batchId}/download?type=results&remoteBasePath=${encodeURIComponent(remoteBasePath)}`}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 hover:bg-surface-50 text-surface-600 rounded-md text-xs font-semibold transition-colors"
                      title="Download CSV & PDB Only"
                    >
                      <FileText className="w-3.5 h-3.5" />
                      Results (.tar.gz)
                    </a>
                  </div>
                  {confirmBatchAction?.id === batchId ? (
                    <div className="flex items-center gap-2 bg-rose-50 border border-rose-200 rounded-lg p-1.5 shadow-sm animate-in fade-in zoom-in-95 duration-200">
                      <span className="text-xs font-bold text-rose-800 px-2">
                        {confirmBatchAction.action === 'cancel' ? 'Cancel Batch?' : 'Delete Batch?'}
                      </span>
                      <button 
                        onClick={() => confirmBatchAction.action === 'cancel' ? handleBatchCancel(batchId) : handleBatchDelete(batchId)}
                        className="px-3 py-1.5 bg-rose-500 hover:bg-rose-600 text-white text-xs font-bold rounded-md transition-colors"
                      >
                        Confirm
                      </button>
                      <button 
                        onClick={() => setConfirmBatchAction(null)}
                        className="px-3 py-1.5 bg-white hover:bg-surface-50 text-surface-600 text-xs font-bold rounded-md border border-surface-200 transition-colors"
                      >
                        Cancel
                      </button>
                    </div>
                  ) : (
                    <>
                      <button 
                        onClick={() => setConfirmBatchAction({ id: batchId, action: 'cancel' })}
                        className="inline-flex items-center gap-2 bg-white border border-surface-200 hover:bg-amber-50 hover:text-amber-600 hover:border-amber-200 text-surface-600 py-1.5 px-3 rounded-lg text-xs font-semibold transition-colors shadow-sm"
                      >
                        <XCircle className="w-3.5 h-3.5" />
                        Cancel All
                      </button>
                      <button 
                        onClick={() => setConfirmBatchAction({ id: batchId, action: 'delete' })}
                        className="inline-flex items-center gap-2 bg-white border border-surface-200 hover:bg-rose-50 hover:text-rose-600 hover:border-rose-200 text-surface-600 py-1.5 px-3 rounded-lg text-xs font-semibold transition-colors shadow-sm"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        Delete All
                      </button>
                    </>
                  )}
                </div>
              </div>
              
              <div className="overflow-x-auto flex-1">
                <table className="w-full text-left border-collapse min-w-[500px]">
                  <thead>
                    <tr className="border-b border-surface-100 text-xs font-bold text-surface-500 uppercase tracking-wider bg-white">
                      <th className="p-4 pl-6">Target Name</th>
                      <th className="p-4">Status</th>
                      <th className="p-4 pr-6 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-surface-100">
                    {records.map(target => (
                      <tr key={`${batchId}-${target.name}`} className="hover:bg-surface-50/50 transition-colors group">
                        <td className="p-4 pl-6 text-sm font-medium text-surface-900 font-mono">
                          {target.name}
                        </td>
                        <td className="p-4">
                          <StatusBadge status={target.status} />
                        </td>
                        <td className="p-4 pr-6 text-right">
                          <div className="flex items-center justify-end gap-2 opacity-100 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity">
                            {target.status === 'Completed' && (
                              <div className="flex items-center gap-1">
                                <a 
                                  href={`/api/jobs/${batchId}/download/${encodeURIComponent(target.name)}?type=all&remoteBasePath=${encodeURIComponent(remoteBasePath)}`}
                                  download
                                  title="Download Target Results (All)"
                                  className="inline-flex items-center justify-center w-8 h-8 bg-white border border-surface-200 hover:bg-brand-50 hover:text-brand-600 hover:border-brand-200 text-surface-500 rounded-lg transition-colors shadow-sm"
                                >
                                  <FileArchive className="w-4 h-4" />
                                </a>
                                <a 
                                  href={`/api/jobs/${batchId}/download/${encodeURIComponent(target.name)}?type=results&remoteBasePath=${encodeURIComponent(remoteBasePath)}`}
                                  download
                                  title="Download Target Results (CSV & PDB Only)"
                                  className="inline-flex items-center justify-center w-8 h-8 bg-white border border-surface-200 hover:bg-brand-50 hover:text-brand-600 hover:border-brand-200 text-surface-500 rounded-lg transition-colors shadow-sm"
                                >
                                  <FileText className="w-4 h-4" />
                                </a>
                              </div>
                            )}
                            
                            {['Predicting', 'Preprocessing', 'Pending Fold', 'Pending MSA'].includes(target.status) && (
                              <button 
                                onClick={() => handleCancelTarget(batchId, target.name)}
                                title="Cancel Job"
                                className="inline-flex items-center justify-center w-8 h-8 bg-white border border-amber-200 hover:bg-amber-50 text-amber-500 rounded-lg transition-colors shadow-sm"
                              >
                                <XCircle className="w-4 h-4" />
                              </button>
                            )}

                            {confirmDelete === `${batchId}-${target.name}` ? (
                              <div className="flex items-center gap-1 bg-rose-50 border border-rose-200 rounded-lg p-1 shadow-sm animate-in fade-in zoom-in-95 duration-200">
                                <button 
                                  onClick={() => handleDeleteTarget(batchId, target.name)}
                                  className="px-2 py-1 bg-rose-500 hover:bg-rose-600 text-white text-xs font-bold rounded-md transition-colors"
                                >
                                  Confirm
                                </button>
                                <button 
                                  onClick={() => setConfirmDelete(null)}
                                  className="px-2 py-1 bg-white hover:bg-surface-50 text-surface-600 text-xs font-bold rounded-md border border-surface-200 transition-colors"
                                >
                                  Cancel
                                </button>
                              </div>
                            ) : (
                              <button 
                                onClick={() => setConfirmDelete(`${batchId}-${target.name}`)}
                                title="Delete Record"
                                className="inline-flex items-center justify-center w-8 h-8 bg-white border border-surface-200 hover:bg-rose-50 hover:text-rose-600 hover:border-rose-200 text-surface-500 rounded-lg transition-colors shadow-sm"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ))}

          {/* Pagination Controls */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between bg-white border border-surface-200 px-4 py-3 rounded-2xl shadow-sm">
              <p className="text-sm text-surface-500">
                Showing <span className="font-semibold text-surface-900">{((currentPage - 1) * RECORDS_PER_PAGE) + 1}</span> to <span className="font-semibold text-surface-900">{Math.min(currentPage * RECORDS_PER_PAGE, allRecords.length)}</span> of <span className="font-semibold text-surface-900">{allRecords.length}</span> records
              </p>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                  disabled={currentPage === 1}
                  className="inline-flex items-center justify-center w-8 h-8 rounded-lg border border-surface-200 hover:bg-surface-50 text-surface-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <div className="text-sm font-semibold text-surface-700 px-2">
                  Page {currentPage} of {totalPages}
                </div>
                <button
                  onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                  disabled={currentPage === totalPages}
                  className="inline-flex items-center justify-center w-8 h-8 rounded-lg border border-surface-200 hover:bg-surface-50 text-surface-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    
      {viewingResultsFor && (
        <ResultsViewer 
          batchId={viewingResultsFor} 
          remoteBasePath={remoteBasePath} 
          onClose={() => setViewingResultsFor(null)} 
        />
      )}
    </div>
  );
}

