import { toPng } from "html-to-image";
import React, { useState, useEffect, useRef } from 'react';
import { BookOpen, Download, Maximize2, X, SlidersHorizontal, Filter, RotateCcw, RefreshCw, AlertTriangle, Clock, ExternalLink, Database, Activity } from 'lucide-react';
import axios from 'axios';

const displayNames: Record<string, string> = {
  'L_tot': 'Total CDR Length',
  'L': 'Total CDR Length',
  'L3': 'CDR3 Length',
  'C': 'CDR3 Compactness',
  'PSH': 'Patches of Surface Hydrophobicity',
  'PPC': 'Patches of Positive Charge',
  'PNC': 'Patches of Negative Charge',
  'SFvCSP': 'Structural Fv Charge Symmetry Parameter',
  'Mol_Weight': 'Molecular Weight',
  'pI': 'Isoelectric Point (pI)',
  'GRAVY': 'GRAVY (Hydrophobicity)',
  'Instability': 'Instability Index',
  'Charge_pH7.4': 'Charge at pH 7.4',
  'N_Glyco_Count': 'N-Glycosylation Sites'
};

const BoxScatterPlot = ({ data, thresholds, isEnlarged = false }: { data: number[], thresholds: any, isEnlarged?: boolean }) => {
  if (!data || data.length === 0) return null;
  
  const sorted = [...data].sort((a, b) => a - b);
  const min = sorted[0];
  const max = sorted[sorted.length - 1];
  
  // Check format
  const isThera = thresholds.p0 !== undefined;
  const isTAPExtended = thresholds.red_low !== undefined && thresholds.green_25 !== undefined;
  
  const q1 = isThera ? thresholds.p25 : (isTAPExtended ? thresholds.green_25 : sorted[Math.floor(sorted.length * 0.25)]);
  const median = isThera ? thresholds.p50 : sorted[Math.floor(sorted.length * 0.5)];
  const q3 = isThera ? thresholds.p75 : (isTAPExtended ? thresholds.green_75 : sorted[Math.floor(sorted.length * 0.75)]);
  const iqr = q3 - q1;
  
  const whiskerMin = Math.max(min, q1 - 1.5 * iqr);
  const whiskerMax = Math.min(max, q3 + 1.5 * iqr);

  let plotMin, plotMax, plotRange;

  if (isThera) {
    const coreRange = thresholds.p100 - thresholds.p0;
    plotMin = thresholds.p0 - coreRange * 0.05;
    plotMax = thresholds.p100 + coreRange * 0.05;
    plotRange = plotMax - plotMin;
  } else {
    const p5 = thresholds.red_low || min;
    const p95 = thresholds.red_high || thresholds.red || max;
    const coreRange = p95 - p5;
    plotMin = Math.min(q1 - coreRange * 0.2, p5 - coreRange * 0.1);
    plotMax = Math.max(q3 + coreRange * 0.2, p95 + coreRange * 0.1);
    plotRange = plotMax - plotMin;
  }

  const getX = (val: number) => {
    if (plotRange === 0) return '50%';
    const clamped = Math.max(plotMin, Math.min(plotMax, val));
    return `${((clamped - plotMin) / plotRange) * 100}%`;
  };

  const getWidth = (startVal: number, endVal: number) => {
    if (plotRange === 0) return '0%';
    const s = Math.max(plotMin, startVal);
    const e = Math.min(plotMax, endVal);
    if (e <= s) return '0%';
    return `${((e - s) / plotRange) * 100}%`;
  };

  const step = Math.max(1, Math.ceil(sorted.length / (isEnlarged ? 400 : 150)));
  const scatterPoints = sorted.filter((_, i) => i % step === 0 && _ >= plotMin && _ <= plotMax);
  
  const strokeW = isEnlarged ? "2.5" : "1.5";
  const r = isEnlarged ? "2.5" : "1.5";
  const fontSize = isEnlarged ? "12" : "8";

  // Hardcoded colors for html-to-image compatibility (no Tailwind opacity classes)
  const colors = {
    red: "rgba(244, 63, 94, 0.2)",
    amber: "rgba(251, 191, 36, 0.25)",
    greenLight: "rgba(52, 211, 153, 0.15)",
    greenMid: "rgba(52, 211, 153, 0.35)",
    greenDark: "rgba(16, 185, 129, 0.45)"
  };

  return (
    <div className={`w-full relative mt-1 mb-0 select-none pointer-events-none flex flex-col justify-end ${isEnlarged ? 'h-32 px-2' : 'h-16 px-4'}`}>
      <svg className="w-full h-full overflow-hidden rounded-md border border-surface-200" style={{ backgroundColor: '#ffffff' }}>
        
        {/* Background Zones */}
        {isThera ? (
          <>
            <rect x="0%" width={getX(thresholds.p0)} height="100%" fill={colors.red} />
            <rect x={getX(thresholds.p0)} width={getWidth(thresholds.p0, thresholds.p5)} height="100%" fill={colors.amber} />
            <rect x={getX(thresholds.p5)} width={getWidth(thresholds.p5, thresholds.p10)} height="100%" fill={colors.greenLight} />
            <rect x={getX(thresholds.p10)} width={getWidth(thresholds.p10, thresholds.p25)} height="100%" fill={colors.greenMid} />
            <rect x={getX(thresholds.p25)} width={getWidth(thresholds.p25, thresholds.p75)} height="100%" fill={colors.greenDark} />
            <rect x={getX(thresholds.p75)} width={getWidth(thresholds.p75, thresholds.p90)} height="100%" fill={colors.greenMid} />
            <rect x={getX(thresholds.p90)} width={getWidth(thresholds.p90, thresholds.p95)} height="100%" fill={colors.greenLight} />
            <rect x={getX(thresholds.p95)} width={getWidth(thresholds.p95, thresholds.p100)} height="100%" fill={colors.amber} />
            <rect x={getX(thresholds.p100)} width={getWidth(thresholds.p100, Infinity)} height="100%" fill={colors.red} />
          </>
        ) : isTAPExtended ? (
          <>
            <rect x="0%" width={getX(thresholds.red_low)} height="100%" fill={colors.red} />
            <rect x={getX(thresholds.red_low)} width={getWidth(thresholds.red_low, thresholds.amber_low)} height="100%" fill={colors.amber} />
            <rect x={getX(thresholds.amber_low)} width={getWidth(thresholds.amber_low, thresholds.green_25)} height="100%" fill={colors.greenLight} />
            <rect x={getX(thresholds.green_25)} width={getWidth(thresholds.green_25, thresholds.green_75)} height="100%" fill={colors.greenDark} />
            <rect x={getX(thresholds.green_75)} width={getWidth(thresholds.green_75, thresholds.amber_high)} height="100%" fill={colors.greenMid} />
            <rect x={getX(thresholds.amber_high)} width={getWidth(thresholds.amber_high, thresholds.red_high)} height="100%" fill={colors.amber} />
            <rect x={getX(thresholds.red_high)} width={getWidth(thresholds.red_high, Infinity)} height="100%" fill={colors.red} />
          </>
        ) : thresholds.red_low !== undefined ? (
          <>
            <rect x="0%" width={getX(thresholds.red_low)} height="100%" fill={colors.red} />
            <rect x={getX(thresholds.red_low)} width={getWidth(thresholds.red_low, thresholds.amber_low)} height="100%" fill={colors.amber} />
            <rect x={getX(thresholds.amber_low)} width={getWidth(thresholds.amber_low, thresholds.amber_high)} height="100%" fill={colors.greenDark} />
            <rect x={getX(thresholds.amber_high)} width={getWidth(thresholds.amber_high, thresholds.red_high)} height="100%" fill={colors.amber} />
            <rect x={getX(thresholds.red_high)} width={getWidth(thresholds.red_high, Infinity)} height="100%" fill={colors.red} />
          </>
        ) : thresholds.amber !== undefined && thresholds.red !== undefined ? (
          <>
            <rect x="0%" width={getX(thresholds.amber)} height="100%" fill={colors.greenDark} />
            <rect x={getX(thresholds.amber)} width={getWidth(thresholds.amber, thresholds.red)} height="100%" fill={colors.amber} />
            <rect x={getX(thresholds.red)} width={getWidth(thresholds.red, Infinity)} height="100%" fill={colors.red} />
          </>
        ) : null}

        {/* Box and Whisker */}
        <line x1={getX(whiskerMin)} y1="50%" x2={getX(q1)} y2="50%" stroke="#475569" strokeWidth={strokeW} />
        <line x1={getX(q3)} y1="50%" x2={getX(whiskerMax)} y2="50%" stroke="#475569" strokeWidth={strokeW} />
        
        {/* Whisker caps */}
        <line x1={getX(whiskerMin)} y1="40%" x2={getX(whiskerMin)} y2="60%" stroke="#475569" strokeWidth={strokeW} />
        <line x1={getX(whiskerMax)} y1="40%" x2={getX(whiskerMax)} y2="60%" stroke="#475569" strokeWidth={strokeW} />

        {/* Box - Removed backdrop-blur to fix html-to-image black rendering */}
        <rect x={getX(q1)} y="30%" width={getWidth(q1, q3)} height="40%" fill="rgba(255,255,255,0.85)" stroke="#334155" strokeWidth={strokeW} rx={isEnlarged ? "3" : "1.5"} />
        <line x1={getX(median)} y1="30%" x2={getX(median)} y2="70%" stroke="#4f46e5" strokeWidth={isEnlarged ? "3" : "2"} />

        {/* Scatter Points */}
        {scatterPoints.map((val, i) => (
           <circle 
             key={i} 
             cx={getX(val)} 
             cy={`${50 + (Math.random() * 26 - 13)}%`} 
             r={r} 
             fill="rgba(30, 41, 59, 0.7)" 
           />
        ))}
        
        {/* 25% and 75% Text Marks */}
        <text x={getX(q1)} y="88%" fontSize={fontSize} textAnchor="middle" fill="#334155" fontFamily="monospace" fontWeight="bold">25%</text>
        <text x={getX(q3)} y="88%" fontSize={fontSize} textAnchor="middle" fill="#334155" fontFamily="monospace" fontWeight="bold">75%</text>

        {/* Threshold Lines */}
        {isThera && (
          <>
            <line x1={getX(thresholds.p5)} y1="0%" x2={getX(thresholds.p5)} y2="100%" stroke="#fbbf24" strokeWidth={isEnlarged ? "2" : "1"} strokeDasharray="4" />
            <text x={getX(thresholds.p5)} y="12%" fontSize={fontSize} textAnchor="middle" fill="#d97706" fontFamily="monospace" fontWeight="bold">5%</text>
            <line x1={getX(thresholds.p10)} y1="0%" x2={getX(thresholds.p10)} y2="100%" stroke="#34d399" strokeWidth={isEnlarged ? "2" : "1"} strokeDasharray="4" />
            <text x={getX(thresholds.p10)} y="26%" fontSize={fontSize} textAnchor="middle" fill="#059669" fontFamily="monospace" fontWeight="bold">10%</text>
            <line x1={getX(thresholds.p90)} y1="0%" x2={getX(thresholds.p90)} y2="100%" stroke="#34d399" strokeWidth={isEnlarged ? "2" : "1"} strokeDasharray="4" />
            <text x={getX(thresholds.p90)} y="26%" fontSize={fontSize} textAnchor="middle" fill="#059669" fontFamily="monospace" fontWeight="bold">90%</text>
            <line x1={getX(thresholds.p95)} y1="0%" x2={getX(thresholds.p95)} y2="100%" stroke="#fbbf24" strokeWidth={isEnlarged ? "2" : "1"} strokeDasharray="4" />
            <text x={getX(thresholds.p95)} y="12%" fontSize={fontSize} textAnchor="middle" fill="#d97706" fontFamily="monospace" fontWeight="bold">95%</text>
          </>
        )}
        {!isThera && thresholds.red_low !== undefined && (
          <>
            <line x1={getX(thresholds.red_low)} y1="0%" x2={getX(thresholds.red_low)} y2="100%" stroke="#fbbf24" strokeWidth={isEnlarged ? "2" : "1"} strokeDasharray="4" />
            <text x={getX(thresholds.red_low)} y="15%" fontSize={fontSize} textAnchor="middle" fill="#d97706" fontFamily="monospace" fontWeight="bold">{thresholds.red_low}</text>
          </>
        )}
      </svg>
    </div>
  );
};

const MetricDisplay = ({ metric, th }: any) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const chartRef = useRef<HTMLDivElement>(null);
  
  const handleDownload = async () => {
    if (!chartRef.current) return;
    try {
      // Use pixelRatio: 3 to ensure a high-res (300 DPI equivalent) download
      const dataUrl = await toPng(chartRef.current, { pixelRatio: 3, backgroundColor: '#ffffff' });
      const link = document.createElement('a');
      link.download = `${metric}_boxplot.png`;
      link.href = dataUrl;
      link.click();
    } catch (err) {
      console.error('Failed to download image', err);
    }
  };

  const displayName = displayNames[metric] || metric.replace(/_/g, ' ');
  const rows = [];
  
  const countIn = (min, max, incMin=true, incMax=false) => {
    if(!th.raw_data) return 0;
    return th.raw_data.filter((v: number) => {
      const gte = incMin ? v >= min : v > min;
      const lte = incMax ? v <= max : v < max;
      return gte && lte;
    }).length;
  };

  if (th.p0 !== undefined) {
    rows.push({ label: '< 0% (Red)', value: `< ${th.p0}`, dot: 'bg-rose-500', count: countIn(-Infinity, th.p0, false, false) });
    rows.push({ label: '0-5% (Amber)', value: `${th.p0} - ${th.p5}`, dot: 'bg-amber-400', count: countIn(th.p0, th.p5, true, false) });
    rows.push({ label: '5-10%', value: `${th.p5} - ${th.p10}`, dot: 'bg-emerald-200', count: countIn(th.p5, th.p10, true, false) });
    rows.push({ label: '10-25%', value: `${th.p10} - ${th.p25}`, dot: 'bg-emerald-400', count: countIn(th.p10, th.p25, true, false) });
    rows.push({ label: '25-75%', value: `${th.p25} - ${th.p75}`, dot: 'bg-emerald-600', count: countIn(th.p25, th.p75, true, true) });
    rows.push({ label: '75-90%', value: `${th.p75} - ${th.p90}`, dot: 'bg-emerald-400', count: countIn(th.p75, th.p90, false, true) });
    rows.push({ label: '90-95%', value: `${th.p90} - ${th.p95}`, dot: 'bg-emerald-200', count: countIn(th.p90, th.p95, false, true) });
    rows.push({ label: '95-100% (Amber)', value: `${th.p95} - ${th.p100}`, dot: 'bg-amber-400', count: countIn(th.p95, th.p100, false, true) });
    rows.push({ label: '> 100% (Red)', value: `> ${th.p100}`, dot: 'bg-rose-500', count: countIn(th.p100, Infinity, false, false) });
  } else if (th.red_low !== undefined && th.green_25 !== undefined) {
    rows.push({ label: '< 5% (Red)', value: `< ${th.red_low}`, dot: 'bg-rose-500' });
    rows.push({ label: '5%-10% (Amber)', value: `${th.red_low} - ${th.amber_low}`, dot: 'bg-amber-400' });
    rows.push({ label: '10-25% (Green)', value: `${th.amber_low} - ${th.green_25}`, dot: 'bg-emerald-400' });
    rows.push({ label: '25-75% (Green)', value: `${th.green_25} - ${th.green_75}`, dot: 'bg-emerald-600' });
    rows.push({ label: '75-90% (Green)', value: `${th.green_75} - ${th.amber_high}`, dot: 'bg-emerald-400' });
    rows.push({ label: '90%-95% (Amber)', value: `${th.amber_high} - ${th.red_high}`, dot: 'bg-amber-400' });
    rows.push({ label: '> 95% (Red)', value: `> ${th.red_high}`, dot: 'bg-rose-500' });
  } else if (th.red_low !== undefined) {
    rows.push({ label: 'Red (L)', value: `< ${th.red_low}`, dot: 'bg-rose-500' });
    rows.push({ label: 'Amber (L)', value: `${th.red_low} - ${th.amber_low}`, dot: 'bg-amber-400' });
    rows.push({ label: 'Green', value: `${th.amber_low} - ${th.amber_high}`, dot: 'bg-emerald-600' });
    rows.push({ label: 'Amber (H)', value: `${th.amber_high} - ${th.red_high}`, dot: 'bg-amber-400' });
    rows.push({ label: 'Red (H)', value: `> ${th.red_high}`, dot: 'bg-rose-500' });
  } else if (th.amber !== undefined && th.red !== undefined) {
    rows.push({ label: 'Green', value: `≤ ${th.amber}`, dot: 'bg-emerald-600' });
    rows.push({ label: 'Amber', value: `${th.amber} - ${th.red}`, dot: 'bg-amber-400' });
    rows.push({ label: 'Red', value: `> ${th.red}`, dot: 'bg-rose-500' });
  }

  return (
    <>
      <div className="bg-white border border-surface-200 rounded-lg shadow-sm flex flex-col h-full hover:shadow-md transition-shadow">
        <div className="bg-surface-50/80 border-b border-surface-100 px-3 py-2 flex justify-between items-center rounded-t-lg">
          <span className="font-bold text-surface-800 text-[14px] tracking-tight truncate mr-2" title={displayName}>{displayName}</span>
          <span className="text-[10px] text-surface-500 font-mono bg-white border border-surface-200 px-1.5 py-0.5 rounded shadow-sm shrink-0">{metric}</span>
        </div>
        <table className="w-full text-left border-collapse">
          <tbody>
            {rows.map((row, i) => (
              <tr key={i} className="border-b border-surface-50 last:border-0 hover:bg-surface-50 transition-colors">
                <td className="px-3 py-2 text-[15px] font-bold text-surface-700 whitespace-nowrap w-[40%] border-r border-surface-50">
                  <div className="flex items-center gap-2">
                    <span className={`w-2.5 h-2.5 rounded-full shrink-0 shadow-sm ${row.dot}`}></span>
                    {row.label}
                  </div>
                </td>
                <td className="px-3 py-2 text-sm font-mono font-bold text-surface-800 bg-surface-50/50">
                  <div className="flex justify-between items-center">
                    <span>{row.value}</span>
                    {row.count !== undefined && (
                      <span className="text-[10px] bg-surface-200 text-surface-600 px-1.5 py-0.5 rounded ml-2 font-sans font-bold">
                        n={row.count}
                      </span>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {th.raw_data && th.raw_data.length > 0 && (
          <div className="mt-auto px-3 py-2 border-t border-surface-100 bg-surface-50/30 relative group">
            <BoxScatterPlot data={th.raw_data} thresholds={th} />
            <div 
              onClick={() => setIsModalOpen(true)}
              className="absolute inset-0 bg-surface-900/5 hover:bg-surface-900/10 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center cursor-pointer rounded-b-lg backdrop-blur-[1px]"
            >
              <div className="bg-white px-3 py-1.5 rounded-full shadow-sm text-xs font-bold text-surface-700 flex items-center gap-1.5">
                <Maximize2 className="w-3.5 h-3.5" /> Enlarge Plot
              </div>
            </div>
          </div>
        )}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-surface-900/60 backdrop-blur-sm p-4 sm:p-8" onClick={() => setIsModalOpen(false)}>
          <div 
            className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl max-h-full overflow-hidden flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-6 py-4 border-b border-surface-100 flex justify-between items-center bg-surface-50/50">
              <h3 className="font-bold text-surface-800 text-lg flex items-center gap-2">
                {displayName} <span className="text-xs font-mono text-surface-500 bg-white border border-surface-200 px-2 py-0.5 rounded shadow-sm">{metric}</span>
              </h3>
              <div className="flex items-center gap-2">
                <button 
                  onClick={handleDownload}
                  className="inline-flex items-center gap-1.5 bg-brand-50 text-brand-700 hover:bg-brand-100 px-3 py-1.5 rounded-lg text-sm font-bold transition-colors"
                >
                  <Download className="w-4 h-4" /> Download High-Res
                </button>
                <button 
                  onClick={() => setIsModalOpen(false)}
                  className="p-1.5 text-surface-400 hover:text-surface-600 hover:bg-surface-100 rounded-lg transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            
            <div className="p-8 overflow-auto flex-1 bg-surface-50 flex flex-col items-center justify-center">
              <div ref={chartRef} className="w-full bg-white p-6 rounded-xl border border-surface-200 shadow-sm">
                <h4 className="text-center font-bold text-surface-700 mb-6 text-xl">{displayName} Distribution</h4>
                <BoxScatterPlot data={th.raw_data} thresholds={th} isEnlarged={true} />
                <div className="mt-8 flex flex-wrap gap-4 justify-center">
                  {rows.map((row, i) => (
                    <div key={i} className="flex items-center gap-2 bg-surface-50 px-3 py-1.5 rounded-lg border border-surface-100">
                      <span className={`w-3 h-3 rounded-full shadow-sm ${row.dot}`}></span>
                      <span className="text-[15px] font-bold text-surface-700">{row.label}:</span>
                      <span className="text-xs font-mono text-surface-800 font-bold">{row.value}</span>
                      {row.count !== undefined && <span className="text-[10px] bg-surface-200 text-surface-600 px-1.5 py-0.5 rounded ml-1">n={row.count}</span>}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
const MultiSelectDropdown = ({ title, options, selected, onChange, dotColor }: any) => {
  const [open, setOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  const filteredOptions = options.filter((opt: string) => opt.toLowerCase().includes(searchTerm.toLowerCase()));

  return (
    <div className="relative" ref={containerRef}>
      <button 
        onClick={() => setOpen(!open)}
        className="flex items-center justify-between w-[130px] sm:w-[150px] bg-white border border-surface-200 px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium text-surface-700 focus:outline-none hover:bg-surface-50 hover:border-surface-300 transition-all"
      >
        <div className="flex items-center gap-2 truncate">
          <span className={`w-2 h-2 rounded-full ${dotColor}`}></span>
          <span className="truncate">{selected.length === 0 ? "All Options" : `${selected.length} Selected`}</span>
        </div>
        <svg className="w-4 h-4 text-surface-400 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
      </button>

      {open && (
        <div className="absolute z-[100] mt-1 w-64 bg-white border border-surface-200 rounded-xl shadow-lg p-2 flex flex-col gap-1 max-h-[300px] overflow-y-auto">
          <div className="px-2 py-1.5 flex items-center justify-between border-b border-surface-100 mb-1 pb-2">
            <span className="text-[11px] font-bold text-surface-400 uppercase tracking-wider">{title}</span>
            <div className="flex gap-1.5">
              <button 
                onClick={() => onChange([...options])} 
                className="text-[10px] font-bold text-brand-600 hover:text-brand-700 bg-brand-50 hover:bg-brand-100 px-2 py-0.5 rounded-md transition-colors"
              >All</button>
              <button 
                onClick={() => onChange([])} 
                className="text-[10px] font-bold text-surface-500 hover:text-surface-700 bg-surface-100 hover:bg-surface-200 px-2 py-0.5 rounded-md transition-colors"
              >Clear</button>
            </div>
          </div>
          
          <div className="px-2 py-1">
            <input 
              type="text" 
              placeholder="Search..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full text-xs px-2 py-1 border border-surface-200 rounded-md focus:outline-none focus:border-brand-500 focus:ring-1 focus:ring-brand-500"
            />
          </div>

          {filteredOptions.length === 0 && (
            <div className="px-2 py-2 text-xs text-surface-400 text-center">No matches found</div>
          )}
          
          {filteredOptions.map((opt: string) => {
            const isChecked = selected.includes(opt);
            return (
              <label key={opt} className={`flex items-center gap-2 cursor-pointer px-2 py-1.5 rounded-lg text-sm transition-colors ${isChecked ? 'bg-brand-50/70' : 'hover:bg-surface-50'}`}>
                <input 
                  type="checkbox"
                  className="rounded text-brand-600 focus:ring-brand-500 border-surface-300 w-3.5 h-3.5"
                  checked={isChecked}
                  onChange={(e) => {
                    if (e.target.checked) onChange([...selected, opt]);
                    else onChange(selected.filter((s: string) => s !== opt));
                  }}
                />
                <span className={`truncate ${isChecked ? 'text-brand-800 font-semibold' : 'text-surface-600'}`}>{opt}</span>
              </label>
            );
          })}
        </div>
      )}
    </div>
  );
};
interface GuidelinesProps {
  sshConnected: boolean;
  refreshKey: number;
}



export default function Guidelines({ sshConnected, refreshKey }: GuidelinesProps) {
  const [data, setData] = useState<any>(null);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState<any>(null);
  const [loadingTAP, setLoadingTAP] = useState(false);
  const [loadingThera, setLoadingThera] = useState(false);
  const [loadingReset, setLoadingReset] = useState(false);
  const [showConfirmReset, setShowConfirmReset] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<{title: string, type: "success" | "info"} | null>(null);
  const [selectedTapStages, setSelectedTapStages] = useState<string[]>(() => {
    try { return JSON.parse(localStorage.getItem('tapStages') || '[]'); } catch { return []; }
  });
  const [selectedTnpStages, setSelectedTnpStages] = useState<string[]>(() => {
    try { return JSON.parse(localStorage.getItem('tnpStages') || '[]'); } catch { return []; }
  });
  const [selectedTapYears, setSelectedTapYears] = useState<string[]>(() => {
    try { return JSON.parse(localStorage.getItem('tapYears') || '[]'); } catch { return []; }
  });
  const [selectedTnpYears, setSelectedTnpYears] = useState<string[]>(() => {
    try { return JSON.parse(localStorage.getItem('tnpYears') || '[]'); } catch { return []; }
  });
  const [selectedTapTargets, setSelectedTapTargets] = useState<string[]>(() => {
    try { return JSON.parse(localStorage.getItem('tapTargets') || '[]'); } catch { return []; }
  });
  const [selectedTnpTargets, setSelectedTnpTargets] = useState<string[]>(() => {
    try { return JSON.parse(localStorage.getItem('tnpTargets') || '[]'); } catch { return []; }
  });

  useEffect(() => {
    localStorage.setItem('tapStages', JSON.stringify(selectedTapStages));
  }, [selectedTapStages]);

  useEffect(() => {
    localStorage.setItem('tnpStages', JSON.stringify(selectedTnpStages));
  }, [selectedTnpStages]);

  useEffect(() => {
    localStorage.setItem('tapYears', JSON.stringify(selectedTapYears));
  }, [selectedTapYears]);

  useEffect(() => {
    localStorage.setItem('tnpYears', JSON.stringify(selectedTnpYears));
  }, [selectedTnpYears]);

  useEffect(() => {
    localStorage.setItem('tapTargets', JSON.stringify(selectedTapTargets));
  }, [selectedTapTargets]);

  useEffect(() => {
    localStorage.setItem('tnpTargets', JSON.stringify(selectedTnpTargets));
  }, [selectedTnpTargets]);

  const fetchGuidelines = async () => {
    try {
      const params = new URLSearchParams();
      if (selectedTapStages.length > 0) params.append('tapStages', selectedTapStages.join(','));
      if (selectedTnpStages.length > 0) params.append('tnpStages', selectedTnpStages.join(','));
      if (selectedTapYears.length > 0) params.append('tapYears', selectedTapYears.join(','));
      if (selectedTnpYears.length > 0) params.append('tnpYears', selectedTnpYears.join(','));
      if (selectedTapTargets.length > 0) params.append('tapTargets', selectedTapTargets.join(','));
      if (selectedTnpTargets.length > 0) params.append('tnpTargets', selectedTnpTargets.join(','));
      const res = await axios.get(`/api/guidelines?${params.toString()}`);
      setData(res.data);
    } catch (err: any) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchGuidelines();
  }, [selectedTapStages, selectedTnpStages, selectedTapYears, selectedTnpYears, selectedTapTargets, selectedTnpTargets, refreshKey]);

  const handleSyncTheraSAbDab = async () => {
    setLoadingThera(true);
    setError(null);
    try {
      const res = await axios.post('/api/guidelines/sync-therasabdab', {});
      setData(res.data);
      if (editing) setDraft(res.data);
      setToastMessage({ title: 'Successfully synced Sequence Properties (TheraSAbDab).', type: 'success' });
      setTimeout(() => setToastMessage(null), 3000);
    } catch (err: any) {
      setError(err.response?.data?.error || err.message);
    } finally {
      setLoadingThera(false);
    }
  };

  const handleSync = async () => {
    setLoadingTAP(true);
    setError(null);
    try {
      const res = await axios.post('/api/guidelines/sync', {});
      setData(res.data);
      if (editing) setDraft(res.data);
      setToastMessage({ title: 'Successfully synced Sequence Properties (TheraSAbDab).', type: 'success' });
      setTimeout(() => setToastMessage(null), 3000);
    } catch (err: any) {
      setError(err.response?.data?.error || err.message);
    } finally {
      setLoadingTAP(false);
    }
  };

  const handleReset = async () => {
    setShowConfirmReset(false);
    setLoadingReset(true);
    setError(null);
    try {
      const res = await axios.post('/api/guidelines/reset');
      setSelectedTapStages([]);
      setSelectedTnpStages([]);
      setSelectedTapYears([]);
      setSelectedTnpYears([]);
      setSelectedTapTargets([]);
      setSelectedTnpTargets([]);
      setData(res.data);
      setToastMessage({ title: 'All datasets and filters have been reset to defaults.', type: 'success' });
      setTimeout(() => setToastMessage(null), 3000);
    } catch (err: any) {
      setError(err.response?.data?.error || err.message);
    } finally {
      setLoadingReset(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    setError(null);
    try {
      const res = await axios.post('/api/guidelines', draft);
      setData(res.data);
      setEditing(false);
      setDraft(null);
      setToastMessage({ title: 'Settings saved successfully.', type: 'success' });
      setTimeout(() => setToastMessage(null), 3000);
    } catch (err: any) {
      setError(err.response?.data?.error || err.message);
    } finally {
      setSaving(false);
    }
  };

  const startEditing = () => {
    setDraft(JSON.parse(JSON.stringify(data)));
    setEditing(true);
  };

  const cancelEditing = () => {
    setEditing(false);
    setDraft(null);
    setError(null);
  };

  const updateDraft = (domain: string, metric: string, key: string, value: number) => {
    setDraft((prev: any) => ({
      ...prev,
      [domain]: {
        ...prev[domain],
        [metric]: {
          ...prev[domain][metric],
          [key]: value
        }
      }
    }));
  };

  const updateTheraSAbDabDraft = (type: string, chain: string, metric: string, key: string, value: number) => {
    setDraft((prev: any) => ({
      ...prev,
      therasabdab: {
        ...prev.therasabdab,
        [type]: {
          ...prev.therasabdab[type],
          [chain]: {
            ...prev.therasabdab[type][chain],
            [metric]: {
              ...prev.therasabdab[type][chain][metric],
              [key]: value
            }
          }
        }
      }
    }));
  };

  if (!data) {
    return (
      <div className="flex items-center justify-center h-64 text-surface-400">
        <RefreshCw className="w-6 h-6 animate-spin" />
      </div>
    );
  }

  const displayData = data;

  return (
    <div className="max-w-7xl mx-auto pb-12 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="sticky top-0 z-30 bg-surface-50 pt-[140px] md:pt-[100px] pb-6 -mt-[140px] md:-mt-[100px] pointer-events-none mb-4 -mx-4 px-4 sm:-mx-0 sm:px-0">
        <div className="bg-white border border-surface-200 rounded-2xl shadow-sm transition-all pointer-events-auto flex flex-col mb-2 overflow-visible">
          <div className="p-4 sm:p-5 flex flex-col xl:flex-row xl:items-center justify-between gap-5 bg-white rounded-2xl">
            <div className="flex items-center gap-4 shrink-0">
              <div className="w-10 h-10 rounded-xl bg-brand-50 flex items-center justify-center shrink-0 border border-brand-100 shadow-inner">
                <SlidersHorizontal className="w-5 h-5 text-brand-600" />
              </div>
              <div>
                <h3 className="font-bold text-surface-900 text-base sm:text-lg tracking-tight">Data Filters & Controls</h3>
                <p className="text-xs sm:text-sm font-medium text-surface-500 mt-0.5">Filter clinical stages and threshold settings</p>
              </div>
            </div>
            
            <div className="flex flex-wrap items-center gap-4 w-full xl:w-auto justify-start xl:justify-end">
              <div className="flex flex-col gap-2 w-full sm:w-auto">
                <div className="flex items-center bg-surface-50 border border-surface-200 rounded-xl p-1 shadow-sm overflow-visible w-full sm:w-auto">
                  <div className="px-3 py-1.5 text-xs font-bold text-brand-600 uppercase tracking-wider flex items-center gap-1.5 shrink-0 w-[80px]">
                    <Filter className="w-3.5 h-3.5" /> TAP
                  </div>
                  <div className="h-5 w-px bg-surface-300 mx-1 shrink-0"></div>
                  <MultiSelectDropdown 
                    title="TAP Stages" 
                    options={data?.metadata?.availableTapStages || []} 
                    selected={selectedTapStages} 
                    onChange={setSelectedTapStages} 
                    dotColor="bg-brand-500" 
                  />
                  <div className="h-5 w-px bg-surface-200 mx-1 shrink-0"></div>
                  <MultiSelectDropdown 
                    title="TAP Years" 
                    options={data?.metadata?.availableTapYears || []} 
                    selected={selectedTapYears} 
                    onChange={setSelectedTapYears} 
                    dotColor="bg-brand-500" 
                  />
                  <div className="h-5 w-px bg-surface-200 mx-1 shrink-0"></div>
                  <MultiSelectDropdown 
                    title="TAP Targets" 
                    options={data?.metadata?.availableTapTargets || []} 
                    selected={selectedTapTargets} 
                    onChange={setSelectedTapTargets} 
                    dotColor="bg-brand-500" 
                  />
                </div>

                <div className="flex items-center bg-surface-50 border border-surface-200 rounded-xl p-1 shadow-sm overflow-visible w-full sm:w-auto">
                  <div className="px-3 py-1.5 text-xs font-bold text-emerald-600 uppercase tracking-wider flex items-center gap-1.5 shrink-0 w-[80px]">
                    <Filter className="w-3.5 h-3.5" /> TNP
                  </div>
                  <div className="h-5 w-px bg-surface-300 mx-1 shrink-0"></div>
                  <MultiSelectDropdown 
                    title="TNP Stages" 
                    options={data?.metadata?.availableTnpStages || []} 
                    selected={selectedTnpStages} 
                    onChange={setSelectedTnpStages} 
                    dotColor="bg-emerald-500"
                  />
                  <div className="h-5 w-px bg-surface-200 mx-1 shrink-0"></div>
                  <MultiSelectDropdown 
                    title="TNP Years" 
                    options={data?.metadata?.availableTnpYears || []} 
                    selected={selectedTnpYears} 
                    onChange={setSelectedTnpYears} 
                    dotColor="bg-emerald-500" 
                  />
                  <div className="h-5 w-px bg-surface-200 mx-1 shrink-0"></div>
                  <MultiSelectDropdown 
                    title="TNP Targets" 
                    options={data?.metadata?.availableTnpTargets || []} 
                    selected={selectedTnpTargets} 
                    onChange={setSelectedTnpTargets} 
                    dotColor="bg-emerald-500" 
                  />
                </div>
              </div>

              <div className="h-12 w-px bg-surface-200 mx-1 hidden xl:block"></div>

              <div className="flex flex-wrap items-center gap-2 whitespace-nowrap w-full sm:w-auto mt-2 sm:mt-0 justify-start sm:justify-end">
                  {showConfirmReset ? (
                    <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-start bg-rose-50 border border-rose-200 p-1.5 rounded-xl">
                      <span className="text-xs font-bold text-rose-600 px-2 shrink-0">Are you sure?</span>
                      <div className="flex items-center gap-1.5 shrink-0">
                        <button onClick={handleReset} disabled={loadingReset} className="inline-flex items-center justify-center bg-rose-600 hover:bg-rose-700 text-white py-1.5 px-3 rounded-lg text-xs font-bold shadow-sm transition-all disabled:opacity-50">Yes</button>
                        <button onClick={() => setShowConfirmReset(false)} className="inline-flex items-center justify-center bg-white hover:bg-surface-50 text-surface-700 py-1.5 px-3 rounded-lg text-xs font-bold shadow-sm transition-all border border-surface-200">No</button>
                      </div>
                    </div>
                  ) : (
                    <button 
                      onClick={() => setShowConfirmReset(true)}
                      disabled={loadingReset}
                      className="flex-1 sm:flex-none justify-center inline-flex items-center gap-2 bg-white border border-surface-300 hover:bg-rose-50 hover:border-rose-200 hover:text-rose-600 text-surface-700 py-2 px-4 rounded-xl text-sm font-bold transition-all shadow-sm disabled:opacity-50"
                    >
                      <RotateCcw className={`w-4 h-4 ${loadingReset ? 'animate-spin' : ''}`} /> <span className="hidden sm:inline">{loadingReset ? 'Resetting...' : 'Reset'}</span>
                    </button>
                  )}
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {toastMessage && (
        <div className={`mb-6 p-4 rounded-xl text-sm flex items-start gap-3 shadow-sm border ${toastMessage.type === 'success' ? 'bg-emerald-50 border-emerald-200 text-emerald-800' : 'bg-brand-50 border-brand-200 text-brand-800'}`}>
          <div className="flex-1 font-semibold">{toastMessage.title}</div>
          <button onClick={() => setToastMessage(null)} className="opacity-70 hover:opacity-100">✕</button>
        </div>
      )}


      {error && (
        <div className="mb-6 p-4 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-sm flex items-start gap-3 shadow-sm">
          <AlertTriangle className="w-5 h-5 shrink-0" />
          <p className="font-medium">{error}</p>
        </div>
      )}

      <div className="bg-surface-50 border border-surface-200 rounded-2xl overflow-hidden shadow-sm mb-12">
        <div className="p-4 border-b border-surface-200 bg-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-brand-50 flex items-center justify-center">
              <Clock className="w-4 h-4 text-brand-600" />
            </div>
            <div>
              <h3 className="font-semibold text-surface-800">OPIG Parameter Cache</h3>
              <p className="text-xs text-surface-500 mt-0.5">Thresholds extracted from OPIG's Therapeutic Antibody/Nanobody Profilers</p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-3">
             <div className="text-xs font-medium text-surface-500 bg-surface-50 px-3 py-1.5 rounded-lg border border-surface-200 flex items-center gap-1.5">
               <Clock className="w-3.5 h-3.5" />
               {data.lastSynced ? new Date(data.lastSynced).toLocaleString() : 'Using Defaults'}
             </div>
          </div>
        </div>
        
        <div className="p-8 space-y-12">
          {/* TAP 2024 */}
          <section>
            <div className="mb-6">
              <h4 className="text-lg font-bold text-surface-900 tracking-tight flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-brand-500"></span>
                TAP 2024 Guidelines (Antibodies)
                <span className="ml-2 text-xs font-semibold bg-brand-100 text-brand-700 px-2 py-0.5 rounded-full">N = {displayData.therasabdab.count_VHVL || 0}</span>
              </h4>
              <p className="text-sm text-surface-500 mt-1 pl-4">Therapeutic Antibody Profiler metrics for conventional antibodies (Defaults derived from 664 clinical-stage therapeutics).</p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2 gap-4">
              {Object.entries(displayData.tap || {}).map(([metric, th]: [string, any]) => (
                <MetricDisplay key={metric} metric={metric} th={th} />
              ))}
            </div>
          </section>

          <hr className="border-surface-200" />

          {/* TNP 2025 */}
          <section>
            <div className="mb-6">
              <h4 className="text-lg font-bold text-surface-900 tracking-tight flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                TNP 2025 Guidelines (Nanobodies)
                <span className="ml-2 text-xs font-semibold bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full">N = {displayData.therasabdab.count_VHH || 0}</span>
              </h4>
              <p className="text-sm text-surface-500 mt-1 pl-4">Therapeutic Nanobody Profiler metrics optimized for single-domain antibodies (Defaults derived from 36 clinical-stage nanobodies).</p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2 gap-4">
              {Object.entries(displayData.tnp || {}).map(([metric, th]: [string, any]) => (
                <MetricDisplay key={metric} metric={metric} th={th} />
              ))}
            </div>
          </section>
        </div>
      </div>

      {/* TheraSAbDab Section */}
      {displayData.therasabdab && (
        <div className="bg-surface-50 border border-surface-200 rounded-2xl overflow-hidden shadow-sm mb-12">
          <div className="p-4 border-b border-surface-200 bg-white flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-teal-50 flex items-center justify-center shrink-0">
                <Activity className="w-4 h-4 text-teal-600" />
              </div>
              <div>
                <h3 className="font-semibold text-surface-800">Sequence Properties Guidelines (TheraSAbDab)</h3>
                <p className="text-xs text-surface-500 mt-0.5">Thresholds derived dynamically from clinical stage non-redundant datasets</p>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              
              <div className="text-xs font-medium text-surface-500 bg-surface-50 px-3 py-1.5 rounded-lg border border-surface-200 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5" />
                {data.therasabdabLastSynced ? new Date(data.therasabdabLastSynced).toLocaleString() : 'Using Defaults'}
              </div>
            </div>
          </div>
          
          <div className="p-8 space-y-12">
            {['VHVL', 'VHH'].map(type => {
              if (!displayData.therasabdab[type]) return null;
              return (
                <section key={type}>
                  <div className="mb-6">
                    <h4 className="text-lg font-bold text-surface-900 tracking-tight flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-teal-500"></span>
                      {type === 'VHVL' ? 'mAb Sequence Properties (Antibodies)' : 'VHH Sequence Properties (Nanobodies)'}
                      {displayData.therasabdab[`count_${type}`] && (
                        <span className="ml-2 text-xs font-semibold bg-teal-100 text-teal-700 px-2 py-0.5 rounded-full">
                          N = {displayData.therasabdab[`count_${type}`]}
                        </span>
                      )}
                    </h4>
                  </div>
                  
                  <div className="space-y-8">
                    {Object.keys(displayData.therasabdab[type]).map(chain => (
                      <div key={chain} className="bg-white border border-surface-200 p-6 rounded-xl shadow-sm">
                        <h5 className="font-semibold text-surface-800 mb-5 pb-3 border-b border-surface-100">{chain} Chain Properties</h5>
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2 gap-4">
                          {Object.keys(displayData.therasabdab[type][chain]).map(prop => {
                            const stats = displayData.therasabdab[type][chain][prop];
                            return editing ? (
                              <MetricDisplay 
                                key={prop} 
                                metric={prop} 
                                th={stats} 
                                onChange={(k: string, v: number) => updateTheraSAbDabDraft(type, chain, prop, k, v)} 
                              />
                            ) : (
                              <MetricDisplay 
                                key={prop} 
                                metric={prop} 
                                th={stats} 
                              />
                            );
                          })}
                        </div>
                      </div>
                    ))}
                  </div>
                </section>
              );
            })}
          </div>
        </div>
      )}

      {/* References Footer */}
      <footer className="mt-8 bg-white border border-surface-200 p-6 rounded-2xl shadow-sm text-sm text-surface-600">
        <h4 className="font-semibold text-surface-900 mb-4 uppercase tracking-wider text-xs">References & Citations</h4>
        <ul className="space-y-4">
          <li className="flex items-start gap-3">
            <ExternalLink className="w-4 h-4 text-surface-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-medium text-surface-800">Therapeutic Antibody Profiler (TAP)</p>
              <p className="text-surface-500 mt-0.5 leading-relaxed">
                Raybould, M. I. J. et al. Contextualising the developability risk of antibodies with lambda light chains using enhanced therapeutic antibody profiling. <i className="text-surface-700">Communications Biology</i> 7:62 (2024).
              </p>
              <a href="https://doi.org/10.1038/s42003-023-05744-8" target="_blank" rel="noreferrer" className="text-brand-600 hover:text-brand-700 hover:underline mt-1 inline-block font-mono text-xs">https://doi.org/10.1038/s42003-023-05744-8</a>
            </div>
          </li>
          <li className="flex items-start gap-3">
            <ExternalLink className="w-4 h-4 text-surface-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-medium text-surface-800">Therapeutic Nanobody Profiler (TNP)</p>
              <p className="text-surface-500 mt-0.5 leading-relaxed">
                Gordon, G. L. et al. The Therapeutic Nanobody Profiler: characterising and predicting nanobody developability to improve therapeutic design. <i className="text-surface-700">bioRxiv</i> (2025).
              </p>
              <a href="https://doi.org/10.1101/2025.08.11.669635" target="_blank" rel="noreferrer" className="text-brand-600 hover:text-brand-700 hover:underline mt-1 inline-block font-mono text-xs">https://doi.org/10.1101/2025.08.11.669635</a>
            </div>
          </li>
          <li className="flex items-start gap-3">
            <ExternalLink className="w-4 h-4 text-surface-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-medium text-surface-800">TheraSAbDab</p>
              <p className="text-surface-500 mt-0.5 leading-relaxed">
                Raybould, M. I. J. et al. TheraSAbDab: the Therapeutic Structural Antibody Database. <i className="text-surface-700">Nucleic Acids Research</i> (2019).
              </p>
              <a href="https://opig.stats.ox.ac.uk/webapps/sabdab-sabpred/sabdab/therapeutics/" target="_blank" rel="noreferrer" className="text-brand-600 hover:text-brand-700 hover:underline mt-1 inline-block font-mono text-xs">https://opig.stats.ox.ac.uk/webapps/sabdab-sabpred/sabdab/therapeutics/</a>
            </div>
          </li>
        </ul>
      </footer>
    </div>
  );
}
