import { toast } from 'sonner';
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import ExcelJS from 'exceljs';
import { saveAs } from 'file-saver';
import { Loader2, AlertTriangle, FileText, Download, Sheet } from 'lucide-react';

interface ResultsViewerProps {
  batchId: string;
  remoteBasePath: string;
  onClose: () => void;
}

export default function ResultsViewer({ batchId, remoteBasePath, onClose }: ResultsViewerProps) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [tapData, setTapData] = useState<string[][]>([]);
  const [tnpData, setTnpData] = useState<string[][]>([]);
  const [guidelines, setGuidelines] = useState<any>(null);

  useEffect(() => {
    fetchResults();
  }, []);

  const calculateDynamicFlag = (header: string, valStr: string, isTNP: boolean) => {
    if (!guidelines || valStr === '') return null;
    let baseHeader = header.replace('_Value', '');
    
    // Check if it's a structural property (Deamidation, etc) that is a string
    const match = baseHeader.match(/^(VH|VL|VHH)_(.*)$/);
    if (match) {
        const prop = match[2];
        if (prop === 'Deamidation' || prop === 'Isomerization' || prop === 'Cleavage' || prop === 'Oxidation') {
            if (valStr && valStr !== 'None') return 'AMBER';
            else if (valStr === 'None') return 'GREEN';
            return null;
        }
        if (prop === 'Cys') {
            if (valStr.includes('Free: Yes')) return 'RED';
            else if (valStr.includes('Free: No')) return 'GREEN';
            return null;
        }
        if (prop === 'NGlycSites') {
            if (valStr && valStr !== 'None') return 'RED';
            else if (valStr === 'None') return 'DARK_GREEN';
            return null;
        }
    }
    
    const val = parseFloat(valStr);
    if (isNaN(val)) return null;
    
    let stats = null;
    if (isTNP && guidelines.tnp && guidelines.tnp[baseHeader]) {
        stats = guidelines.tnp[baseHeader];
    } else if (!isTNP && guidelines.tap && guidelines.tap[baseHeader]) {
        stats = guidelines.tap[baseHeader];
    }
    
    if (!stats && guidelines.therasabdab && match) {
        const chain = match[1];
        const prop = match[2];
        let statsKey = prop;
        if (prop === 'MW') statsKey = 'Mol_Weight';
        if (prop === 'Charge') statsKey = 'Charge_pH7.4';
        if (prop === 'NGlyc' || prop === 'NGlycSites') statsKey = 'N_Glyco_Count';
        
        const dataset = isTNP ? guidelines.therasabdab.VHH : guidelines.therasabdab.VHVL;
        let lookupChain = chain;
        stats = dataset?.[lookupChain]?.[statsKey];
        
        if (statsKey === 'N_Glyco_Count') {
            if (val > 0) return 'RED';
            else return 'DARK_GREEN';
        }
    }
    
    if (stats && stats.count !== 0 && (stats.p0 !== undefined || stats.red_low !== undefined || stats.amber !== undefined || stats.red !== undefined)) {
        if (stats.p0 !== undefined) {
            if (val < stats.p0 || val > stats.p100) return 'RED';
            else if (val < stats.p5 || val > stats.p95) return 'AMBER';
            else if (val < stats.p10 || val > stats.p90) return 'LIGHT_GREEN';
            else if (val < stats.p25 || val > stats.p75) return 'MID_GREEN';
            else return 'DARK_GREEN';
        } else if (stats.red_low !== undefined && stats.green_25 !== undefined) {
            if (val < stats.red_low || val > stats.red_high) return 'RED';
            else if (val < stats.amber_low || val > (stats.amber_high || Infinity)) return 'AMBER';
            else if (val < stats.green_25 || val > stats.green_75) return 'LIGHT_GREEN';
            else if (val >= stats.green_25 && val <= stats.green_75) return 'DARK_GREEN';
            else return 'MID_GREEN';
        } else {
            if (val < stats.red_low || val > (stats.red_high || Infinity)) return 'RED';
            else if ((val >= stats.red_low && val <= (stats.amber_low || Infinity)) || (val >= (stats.amber_high || -Infinity) && val <= (stats.red_high || Infinity))) return 'AMBER';
            else return 'DARK_GREEN';
        }
    }
    return null;
  };

  const fetchResults = async () => {
    try {
      const tapStages = JSON.parse(localStorage.getItem('tapStages') || '[]');
      const tnpStages = JSON.parse(localStorage.getItem('tnpStages') || '[]');
      const params = new URLSearchParams();
      if (tapStages.length > 0) params.append('tapStages', tapStages.join(','));
      if (tnpStages.length > 0) params.append('tnpStages', tnpStages.join(','));
      
      const [res, guidelinesRes] = await Promise.all([
        axios.get(`/api/jobs/${batchId}/results?remoteBasePath=${encodeURIComponent(remoteBasePath)}`),
        axios.get(`/api/guidelines?${params.toString()}`)
      ]);
      setGuidelines(guidelinesRes.data);
      
            const parseCsv = (csvStr: string) => {
        if (!csvStr || csvStr.trim() === '') return [];
        const parsed = csvStr.trim().split('\n').map(line => {
        const cleanLine = line.replace(/\r$/, '');
        const row = [];
        let cur = '';
        let inQuote = false;
        for (let i = 0; i < cleanLine.length; i++) {
          const char = cleanLine[i];
          if (char === '"' && cleanLine[i+1] === '"') {
            cur += '"';
            i++;
          } else if (char === '"') {
            inQuote = !inQuote;
          } else if (char === ',' && !inQuote) {
            row.push(cur);
            cur = '';
          } else {
            cur += char;
          }
        }
        row.push(cur);
        return row;
      });
      
      // Sort data by Filename / Target_Name
      if (parsed.length > 1) {
          const headers = parsed[0];
          const filenameIdx = headers.findIndex(h => h.toLowerCase() === 'filename' || h.toLowerCase() === 'target_name');
          if (filenameIdx !== -1) {
              const rows = parsed.slice(1);
              rows.sort((a, b) => {
                  const aVal = a[filenameIdx] || '';
                  const bVal = b[filenameIdx] || '';
                  return aVal.localeCompare(bVal, undefined, { numeric: true, sensitivity: 'base' });
              });
              return [headers, ...rows];
          }
      }
      return parsed;
      };

      setTapData(parseCsv(res.data.tapCsv));
      setTnpData(parseCsv(res.data.tnpCsv));
    } catch (err: any) {
      setError(err.response?.data?.error || err.message);
    } finally {
      setLoading(false);
    }
  };


  const handleExportExcel = async () => {
    try {
      const workbook = new ExcelJS.Workbook();
      
      const addSheet = (data, sheetName) => {
        if (data.length <= 1) return;
        const sheet = workbook.addWorksheet(sheetName);
        const headers = data[0];
        const rows = data.slice(1);
        
        const columns = [];
        const headerIndices = [];
        
        headers.forEach((h, i) => {
          if (h.endsWith('_Flag')) return;
          let headerName = h.replace('_Value', '');
          if (headerName === 'Target_Name') headerName = 'Target Name';
          if (headerName === 'L_tot') headerName = 'Total CDR Length (L_tot)';
          if (headerName === 'Error_Message') headerName = 'Error Message';
          columns.push({ header: headerName, width: Math.max(headerName.length + 5, 15) });
          headerIndices.push(i);
        });
        
        sheet.columns = columns;
        
        sheet.getRow(1).font = { bold: true, color: { argb: 'FF334155' } };
        sheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF8FAFC' } };
        
        rows.forEach(row => {
          const rowData = [];
          const cellFlags = [];
          
          headerIndices.forEach((origIdx, colIdx) => {
            const header = headers[origIdx];
            let cellValue = row[origIdx] || '';
                  if (header.endsWith('_Value') || ['L_tot', 'PSH', 'PPC', 'PNC', 'SFvCSP', 'L', 'L3', 'C'].includes(header) || header.includes('MW') || header.includes('pI') || header.includes('GRAVY') || header.includes('Instability') || header.includes('Charge')) {
                       if (cellValue && !isNaN(Number(cellValue)) && cellValue.trim() !== '') {
                           const num = Number(cellValue);
                           if (!Number.isInteger(num)) {
                               cellValue = num.toFixed(2);
                           }
                       }
                  }
            rowData.push(cellValue);
            
            let flag = calculateDynamicFlag(header, cellValue, sheetName.includes('TNP')) || '';
            if (!flag) {
                const flagHeader = header + '_Flag';
                const flagIdx = headers.indexOf(flagHeader);
                if (flagIdx !== -1) flag = row[flagIdx]?.trim().toUpperCase() || '';
                else if (header.endsWith('_Value') && headers[origIdx+1] === header.replace('_Value', '_Flag')) {
                    flag = row[origIdx+1]?.trim().toUpperCase() || '';
                }
            }
            
            if (flag) {
              cellFlags.push({ colNumber: colIdx + 1, flag });
            }
          });
          
          const excelRow = sheet.addRow(rowData);
          
          cellFlags.forEach(({ colNumber, flag }) => {
            const cell = excelRow.getCell(colNumber);
            if (flag === 'RED') {
              cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF43F5E' } };
              cell.font = { color: { argb: 'FFFFFFFF' }, bold: true };
            } else if (flag === 'AMBER') {
              cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFBBF24' } };
              cell.font = { color: { argb: 'FF000000' }, bold: true };
            } else if (flag === 'GREEN' || flag === 'DARK_GREEN' || flag === 'D-GREEN') {
              cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF059669' } };
              cell.font = { color: { argb: 'FFFFFFFF' }, bold: true };
            } else if (flag === 'MID_GREEN' || flag === 'M-GREEN') {
              cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF34D399' } };
              cell.font = { color: { argb: 'FF064E3B' }, bold: true };
            } else if (flag === 'LIGHT_GREEN' || flag === 'L-GREEN') {
              cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFA7F3D0' } };
              cell.font = { color: { argb: 'FF064E3B' }, bold: true };
            }
          });
        });
      };
      
      addSheet(tapData, 'TAP 2024 Antibodies');
      addSheet(tnpData, 'TNP 2025 Nanobodies');
      
      const buffer = await workbook.xlsx.writeBuffer();
      const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      saveAs(blob, `Analysis_Results_${batchId}.xlsx`);
    } catch (err) {
      console.error("Error exporting to Excel:", err);
      toast.error("Failed to export Excel file.");
    }
  };

  const renderTable = (data: string[][], title: string) => {

    if (data.length <= 1) return null;
    const headers = data[0];
    const rows = data.slice(1);

    return (
      <div className="mb-10 last:mb-0 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold text-surface-800">{title}</h3>
          <span className="text-xs font-medium bg-brand-50 text-brand-700 px-2.5 py-1 rounded-full border border-brand-100">
            {rows.length} Targets
          </span>
        </div>
        <div className="overflow-x-auto border border-surface-200 rounded-xl shadow-sm bg-white custom-scrollbar max-h-[60vh]">
          <table className="w-full text-left border-collapse min-w-[800px]">
            <thead className="bg-surface-50">
              <tr>
                {headers.map((h, i) => {
                  if (h.endsWith('_Flag')) return null;
                  const isFirst = i === 0;
                  
                  let headerName = h.replace('_Value', '');
                  if (headerName === 'Target_Name') headerName = 'Target Name';
                  if (headerName === 'L_tot') headerName = 'Total CDR Length (L_tot)';
          if (headerName === 'Error_Message') headerName = 'Error Message';
                  if (headerName === 'PSH') headerName = 'Hydrophobicity (PSH)';
                  if (headerName === 'PPC') headerName = 'Positive Charge (PPC)';
                  if (headerName === 'PNC') headerName = 'Negative Charge (PNC)';
                  if (headerName === 'SFvCSP') headerName = 'Charge Asymmetry (SFvCSP)';
                  if (headerName === 'TAP') headerName = 'TAP Overall';
                  if (headerName === 'L') headerName = 'Total CDR Length (L)';
                  if (headerName === 'L3') headerName = 'CDR3 Length (L3)';
                  if (headerName === 'C') headerName = 'CDR3 Compactness (C)';
                  if (headerName === 'Tetrad') headerName = 'Tetrad (IMGT 42,49,50,52)';
                  if (headerName === 'TNP') headerName = 'TNP Overall';
                  if (headerName.endsWith('_Length')) headerName = headerName.replace('_', ' ') + ' (AAs)';
                  if (headerName.endsWith('_MW')) headerName = headerName.replace('_', ' ') + ' (Da)';
                  if (headerName.endsWith('_pI')) headerName = headerName.replace('_', ' ') + ' (pI)';
                  if (headerName.endsWith('_GRAVY')) headerName = headerName.replace('_', ' ') + ' (GRAVY)';
                  if (headerName.endsWith('_Instability')) headerName = headerName.replace('_', ' ') + ' Index';
                  if (headerName.endsWith('_Charge')) headerName = headerName.replace('_', ' ') + ' (pH 7.4)';
                  if (headerName.endsWith('_NGlyc')) headerName = headerName.replace('_', ' ') + ' (Sites)';
                  if (headerName.endsWith('_NGlycSites')) headerName = headerName.replace('_', ' ') + ' Details';
                  if (headerName.endsWith('_Deamidation')) headerName = headerName.replace('_', ' ');
                  if (headerName.endsWith('_Isomerization')) headerName = headerName.replace('_', ' ');
                  if (headerName.endsWith('_Cleavage')) headerName = headerName.replace('_', ' ');
                  if (headerName.endsWith('_Oxidation')) headerName = headerName.replace('_', ' ');
                  if (headerName.endsWith('_Cys')) headerName = headerName.replace('_', ' ') + ' Status';
                  if (headerName === 'Error_Message') headerName = 'Error Message';
                  return (
                    <th 
                      key={i} 
                      className={`px-5 py-3.5 text-xs font-bold text-surface-600 uppercase tracking-wider whitespace-nowrap sticky top-0 border-b border-surface-200 bg-surface-50 ${isFirst ? 'left-0 shadow-[1px_0_0_0_#e2e8f0] z-40' : 'z-30'}`}
                    >
                      {headerName}
                    </th>
                  );
                })}
              </tr>
            </thead>
            <tbody className="divide-y divide-surface-100 bg-white">
              {rows.map((row, rIdx) => (
                <tr key={rIdx} className="hover:bg-surface-50 transition-colors group">
                  {headers.map((header, cIdx) => {
                    let cell = row[cIdx] || '';
                    if (header.endsWith('_Value') || ['L_tot', 'PSH', 'PPC', 'PNC', 'SFvCSP', 'L', 'L3', 'C'].includes(header) || header.includes('MW') || header.includes('pI') || header.includes('GRAVY') || header.includes('Instability') || header.includes('Charge')) {
                       if (cell && !isNaN(Number(cell)) && cell.trim() !== '') {
                           const num = Number(cell);
                           if (cell.includes('.') || !Number.isInteger(num)) {
                               cell = num.toFixed(2);
                           }
                       }
                    }
                    if (header.endsWith('_Flag')) return null;
                    
                    let flag = calculateDynamicFlag(header, cell, title.includes('TNP')) || '';
                    if (!flag) {
                        const flagHeader = header + '_Flag';
                        const flagIdx = headers.indexOf(flagHeader);
                        if (flagIdx !== -1) flag = row[flagIdx]?.trim().toUpperCase() || '';
                        else if (header.endsWith('_Value') && headers[cIdx+1] === header.replace('_Value', '_Flag')) {
                            flag = row[cIdx+1]?.trim().toUpperCase() || '';
                        }
                    }
                    
                    const isFirst = cIdx === 0;
                    let flagDot = null;
                    if (flag === 'RED') {
                      flagDot = <div className="inline-flex items-center gap-1.5 mt-1.5 px-2 py-0.5 rounded bg-rose-500 text-white font-bold text-[10px] uppercase border border-rose-600 shadow-sm"><span className="w-1.5 h-1.5 rounded-full bg-white"></span>RED</div>;
                    } else if (flag === 'AMBER') {
                      flagDot = <div className="inline-flex items-center gap-1.5 mt-1.5 px-2 py-0.5 rounded bg-amber-400 text-amber-950 font-bold text-[10px] uppercase border border-amber-500 shadow-sm"><span className="w-1.5 h-1.5 rounded-full bg-amber-900"></span>AMBER</div>;
                    } else if (flag === 'LIGHT_GREEN' || flag === 'L-GREEN') {
                      flagDot = <div className="inline-flex items-center gap-1.5 mt-1.5 px-2 py-0.5 rounded bg-emerald-200 text-emerald-950 font-bold text-[10px] uppercase border border-emerald-300 shadow-sm"><span className="w-1.5 h-1.5 rounded-full bg-emerald-700"></span>L-GREEN</div>;
                    } else if (flag === 'MID_GREEN' || flag === 'M-GREEN') {
                      flagDot = <div className="inline-flex items-center gap-1.5 mt-1.5 px-2 py-0.5 rounded bg-emerald-400 text-emerald-950 font-bold text-[10px] uppercase border border-emerald-500 shadow-sm"><span className="w-1.5 h-1.5 rounded-full bg-emerald-900"></span>M-GREEN</div>;
                    } else if (flag === 'GREEN' || flag === 'DARK_GREEN' || flag === 'D-GREEN') {
                      flagDot = <div className="inline-flex items-center gap-1.5 mt-1.5 px-2 py-0.5 rounded bg-emerald-600 text-white font-bold text-[10px] uppercase border border-emerald-700 shadow-sm"><span className="w-1.5 h-1.5 rounded-full bg-white"></span>D-GREEN</div>;
                    }

                    return (
                      <td 
                        key={cIdx} 
                        className={`px-5 py-3 text-sm text-surface-700 whitespace-nowrap ${isFirst ? 'sticky left-0 bg-white group-hover:bg-surface-50 shadow-[1px_0_0_0_#f1f5f9] z-10 font-medium text-surface-900 transition-colors' : ''}`}
                      >
                        <div className="flex flex-col items-start">
                           <span className={isFirst ? "font-semibold" : "font-mono"}>{cell}</span>
                           {flagDot}
                        </div>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  return (
    <div className="fixed inset-0 z-50 bg-surface-900/60 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 lg:p-8">
      <div className="bg-surface-50 rounded-2xl shadow-2xl w-full max-w-[90vw] max-h-[90vh] flex flex-col overflow-hidden animate-in zoom-in-95 duration-200 border border-surface-200/50">
        <div className="px-6 py-5 border-b border-surface-200 flex items-center justify-between bg-white z-20">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 bg-brand-50 text-brand-600 rounded-xl flex items-center justify-center border border-brand-100">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-surface-900 tracking-tight">Analysis Dashboard</h2>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="text-xs text-surface-500">Batch ID:</span>
                <span className="text-xs font-mono font-medium text-surface-700 bg-surface-100 px-1.5 py-0.5 rounded">{batchId}</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={handleExportExcel}
              className="hidden sm:flex items-center gap-2 px-4 py-2 bg-emerald-50 border border-emerald-200 hover:bg-emerald-100 text-emerald-700 rounded-lg text-sm font-semibold transition-all shadow-sm"
            >
              <Sheet className="w-4 h-4 text-emerald-600" />
              Export to Excel
            </button>
            <a 
              href={`/api/jobs/${batchId}/download?type=results&remoteBasePath=${encodeURIComponent(remoteBasePath)}`}
              className="hidden sm:flex items-center gap-2 px-4 py-2 bg-white border border-surface-200 hover:bg-surface-50 text-surface-700 rounded-lg text-sm font-semibold transition-all shadow-sm"
              title="Download raw files (CSV + PDBs)"
            >
              <Download className="w-4 h-4 text-brand-500" />
              Raw (.tar.gz)
            </a>
            <button onClick={onClose} className="p-2.5 bg-surface-100 hover:bg-surface-200 text-surface-600 rounded-lg transition-colors font-semibold shadow-sm">
              ✕
            </button>
          </div>
        </div>

        <div className="p-6 md:p-8 overflow-y-auto flex-1 bg-surface-50">
          {loading ? (
            <div className="flex flex-col items-center justify-center h-full min-h-[400px]">
              <div className="relative">
                <div className="absolute inset-0 bg-brand-200 rounded-full blur-xl animate-pulse opacity-50"></div>
                <Loader2 className="w-10 h-10 animate-spin text-brand-600 relative z-10" />
              </div>
              <p className="mt-4 text-sm font-medium text-surface-600 animate-pulse">Processing analysis data...</p>
            </div>
          ) : error ? (
            <div className="p-6 bg-rose-50 border border-rose-200 rounded-2xl flex flex-col items-center justify-center text-center max-w-lg mx-auto mt-10 shadow-sm">
              <div className="w-12 h-12 bg-rose-100 text-rose-600 rounded-full flex items-center justify-center mb-4">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-rose-900 mb-2">Failed to load results</h3>
              <p className="text-sm text-rose-700">{error}</p>
            </div>
          ) : (
            <div className="space-y-8">
              {tapData.length <= 1 && tnpData.length <= 1 && (
                <div className="p-12 bg-white border border-surface-200 rounded-2xl flex flex-col items-center justify-center text-center shadow-sm">
                  <div className="w-16 h-16 bg-amber-50 text-amber-500 rounded-full flex items-center justify-center mb-4">
                    <AlertTriangle className="w-8 h-8" />
                  </div>
                  <h3 className="text-xl font-bold text-surface-800 mb-2">No Analysis Data Available</h3>
                  <p className="text-surface-500 max-w-md">The job might still be running or hasn't produced CSV results yet. Check the tasks list for completion status.</p>
                </div>
              )}
              {renderTable(tapData, "TAP 2024 Profiling (Antibodies)")}
              {renderTable(tnpData, "TNP 2025 Profiling (Nanobodies)")}
            </div>
          )}
        </div>
      </div>
      
      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 8px;
          height: 8px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: #f8fafc;
          border-radius: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #cbd5e1;
          border-radius: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #94a3b8;
        }
      `}</style>
    </div>
  );
}
