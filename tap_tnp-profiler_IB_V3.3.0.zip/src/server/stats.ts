import * as fs from 'fs';
import * as path from 'path';
import { parse } from 'csv-parse/sync';

function percentile(N: number[], percent: number) {
    if (!N || N.length === 0) return null;
    N.sort((a, b) => a - b);
    const k = (N.length - 1) * percent;
    const f = Math.floor(k);
    const c = Math.ceil(k);
    if (f === c) return N[k];
    const d0 = N[f] * (c - k);
    const d1 = N[c] * (k - f);
    return Math.round((d0 + d1) * 100000) / 100000;
}

function calcThresholds(values: number[]) {
    const valid = values.filter(v => v !== null && !isNaN(v)).sort((a, b) => a - b);
    if (valid.length === 0) return { count: 0 };
    return {
        p0: Math.round(percentile(valid, 0.0)! * 100) / 100,
        p5: Math.round(percentile(valid, 0.05)! * 100) / 100,
        p10: Math.round(percentile(valid, 0.10)! * 100) / 100,
        p25: Math.round(percentile(valid, 0.25)! * 100) / 100,
        p50: Math.round(percentile(valid, 0.50)! * 100) / 100,
        p75: Math.round(percentile(valid, 0.75)! * 100) / 100,
        p90: Math.round(percentile(valid, 0.90)! * 100) / 100,
        p95: Math.round(percentile(valid, 0.95)! * 100) / 100,
        p100: Math.round(percentile(valid, 1.00)! * 100) / 100,
        count: valid.length,
        raw_data: valid.map(v => Math.round(v * 100) / 100)
    };
}

let cachedTapData: any[] | null = null;
let cachedTnpData: any[] | null = null;
let allTapStagesCache: string[] = [];
let allTnpStagesCache: string[] = [];
let allTapYearsCache: string[] = [];
let allTnpYearsCache: string[] = [];
let allTapTargetsCache: string[] = [];
let allTnpTargetsCache: string[] = [];

export function computeGuidelines({ tapStages = [], tnpStages = [], tapYears = [], tnpYears = [], tapTargets = [], tnpTargets = [] }: { tapStages?: string[], tnpStages?: string[], tapYears?: string[], tnpYears?: string[], tapTargets?: string[], tnpTargets?: string[] }) {
    const customTapCsvPath = path.join(process.cwd(), 'uploads/custom_tap.csv');
    const customTnpCsvPath = path.join(process.cwd(), 'uploads/custom_tnp.csv');

    const tapCsvPath = fs.existsSync(customTapCsvPath) ? customTapCsvPath : path.join(process.cwd(), 'src/server/data/Analysis_Results_TAP.csv');
    const tnpCsvPath = fs.existsSync(customTnpCsvPath) ? customTnpCsvPath : path.join(process.cwd(), 'src/server/data/Analysis_Results_TNP.csv');

    // Force read every time to pick up new uploads easily, or we can just always parse it. It's fast.
    if (fs.existsSync(tapCsvPath)) {
        cachedTapData = parse(fs.readFileSync(tapCsvPath, 'utf8').replace(/^\uFEFF/, ''), { columns: true, skip_empty_lines: true });
    } else {
        cachedTapData = [];
    }

    if (fs.existsSync(tnpCsvPath)) {
        cachedTnpData = parse(fs.readFileSync(tnpCsvPath, 'utf8').replace(/^\uFEFF/, ''), { columns: true, skip_empty_lines: true });
    } else {
        cachedTnpData = [];
    }


    const tapStageCol = "Highest_Clin_Trial";
    const tnpStageCol = "Highest_Clin_Trial";

    allTapStagesCache = Array.from(new Set(cachedTapData.map((r: any) => r[tapStageCol]))).filter(s => s && String(s).trim() !== '').sort();
    allTapYearsCache = Array.from(new Set(cachedTapData.map((r: any) => r['Year Proposed']))).filter(s => s && String(s).trim() !== '').sort();
    allTapTargetsCache = Array.from(new Set(cachedTapData.map((r: any) => r['Target']))).filter(s => s && String(s).trim() !== '').sort();
    allTnpStagesCache = Array.from(new Set(cachedTnpData.map((r: any) => r[tnpStageCol]))).filter(s => s && String(s).trim() !== '').sort();
    allTnpYearsCache = Array.from(new Set(cachedTnpData.map((r: any) => r['Year Proposed']))).filter(s => s && String(s).trim() !== '').sort();
    allTnpTargetsCache = Array.from(new Set(cachedTnpData.map((r: any) => r['Target']))).filter(s => s && String(s).trim() !== '').sort();

    let filteredTap = tapStages.length > 0 ? cachedTapData.filter(r => tapStages.includes(r[tapStageCol])) : cachedTapData;
    if (tapYears.length > 0) filteredTap = filteredTap.filter(r => tapYears.includes(String(r['Year Proposed'])));
    if (tapTargets.length > 0) filteredTap = filteredTap.filter(r => tapTargets.includes(String(r['Target'])));
    let filteredTnp = tnpStages.length > 0 ? cachedTnpData.filter(r => tnpStages.includes(r[tnpStageCol])) : cachedTnpData;
    if (tnpYears.length > 0) filteredTnp = filteredTnp.filter(r => tnpYears.includes(String(r['Year Proposed'])));
    if (tnpTargets.length > 0) filteredTnp = filteredTnp.filter(r => tnpTargets.includes(String(r['Target'])));

    const readCol = (data: any[], colName: string) => {
        return data.map(r => parseFloat(r[colName])).filter(v => !isNaN(v));
    };

    const tap = {
        L_tot: calcThresholds(readCol(filteredTap, 'Total CDR Length (L_tot)')),
        PSH: calcThresholds(readCol(filteredTap, 'PSH')),
        PPC: calcThresholds(readCol(filteredTap, 'PPC')),
        PNC: calcThresholds(readCol(filteredTap, 'PNC')),
        SFvCSP: calcThresholds(readCol(filteredTap, 'SFvCSP'))
    };

    const tnp = {
        L: calcThresholds(readCol(filteredTnp, 'L')),
        L3: calcThresholds(readCol(filteredTnp, 'L3')),
        C: calcThresholds(readCol(filteredTnp, 'C')),
        PSH: calcThresholds(readCol(filteredTnp, 'PSH')),
        PPC: calcThresholds(readCol(filteredTnp, 'PPC')),
        PNC: calcThresholds(readCol(filteredTnp, 'PNC'))
    };

    const therasabdab = {
        count_VHVL: filteredTap.length,
        count_VHH: filteredTnp.length,
        VHVL: {
            VH: {
                Mol_Weight: calcThresholds(readCol(filteredTap, 'VH_MW')),
                pI: calcThresholds(readCol(filteredTap, 'VH_pI')),
                GRAVY: calcThresholds(readCol(filteredTap, 'VH_GRAVY')),
                Instability: calcThresholds(readCol(filteredTap, 'VH_Instability')),
                "Charge_pH7.4": calcThresholds(readCol(filteredTap, 'VH_Charge')),
                N_Glyco_Count: calcThresholds(readCol(filteredTap, 'VH_NGlyc'))
            },
            VL: {
                Mol_Weight: calcThresholds(readCol(filteredTap, 'VL_MW')),
                pI: calcThresholds(readCol(filteredTap, 'VL_pI')),
                GRAVY: calcThresholds(readCol(filteredTap, 'VL_GRAVY')),
                Instability: calcThresholds(readCol(filteredTap, 'VL_Instability')),
                "Charge_pH7.4": calcThresholds(readCol(filteredTap, 'VL_Charge')),
                N_Glyco_Count: calcThresholds(readCol(filteredTap, 'VL_NGlyc'))
            }
        },
        VHH: {
            VHH: {
                Mol_Weight: calcThresholds(readCol(filteredTnp, 'VHH_MW')),
                pI: calcThresholds(readCol(filteredTnp, 'VHH_pI')),
                GRAVY: calcThresholds(readCol(filteredTnp, 'VHH_GRAVY')),
                Instability: calcThresholds(readCol(filteredTnp, 'VHH_Instability')),
                "Charge_pH7.4": calcThresholds(readCol(filteredTnp, 'VHH_Charge')),
                N_Glyco_Count: calcThresholds(readCol(filteredTnp, 'VHH_NGlyc'))
            }
        }
    };

    return {
        tap,
        tnp,
        therasabdab,
        metadata: {
            availableTapStages: allTapStagesCache,
            availableTnpStages: allTnpStagesCache,
            availableTapYears: allTapYearsCache,
            availableTnpYears: allTnpYearsCache,
            availableTapTargets: allTapTargetsCache,
            availableTnpTargets: allTnpTargetsCache
        }
    };
}
