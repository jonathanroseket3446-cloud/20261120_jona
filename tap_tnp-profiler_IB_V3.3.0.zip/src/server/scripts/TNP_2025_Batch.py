#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import subprocess
import numpy as np
import warnings
import os
import sys
import tempfile

import csv
import re
from Bio.SeqUtils.ProtParam import ProteinAnalysis

from Bio.PDB import PDBParser, MMCIFParser, PDBIO
from Bio.SeqUtils import seq1
from scipy.spatial.distance import cdist
from Bio import BiopythonWarning

warnings.simplefilter('ignore', BiopythonWarning)

CHARGE_SCALE = {'ASP': -1.0, 'GLU': -1.0, 'LYS': 1.0, 'ARG': 1.0, 'HIS': 0.1}
KD_SCALE = {
    'ARG': -4.5, 'LYS': -3.9, 'ASN': -3.5, 'ASP': -3.5, 'GLN': -3.5,
    'GLU': -3.5, 'HIS': -3.2, 'PRO': -1.6, 'TYR': -1.3, 'TRP': -0.9,
    'SER': -0.8, 'THR': -0.7, 'GLY': -0.4, 'ALA':  1.8, 'MET':  1.9,
    'CYS':  2.5, 'PHE':  2.8, 'LEU':  3.8, 'VAL':  4.2, 'ILE':  4.5
}

def normalize_kd(res_name):
    return 1.0 + (KD_SCALE.get(res_name, 0) + 4.5) / 9.0

IMGT_CDR_ANCHORS = set(
    list(range(25, 41)) + list(range(54, 68)) + list(range(103, 120))
)

THRESHOLDS_THERASABDAB = {}

THRESHOLDS_TNP = {
    'L': {'red_low': 20, 'amber_low': 24, 'amber_high': 37, 'red_high': 39},
    'L3': {'red_low': 5, 'amber_low': 8, 'amber_high': 21, 'red_high': 23},
    'C': {'red_low': 0.56, 'amber_low': 0.81, 'amber_high': 1.57, 'red_high': 1.61},
    'PSH': {'red_low': 73.40, 'amber_low': 79.59, 'amber_high': 126.83, 'red_high': 155.47},
    'PPC': {'amber': 0.39, 'red': 1.18},
    'PNC': {'amber': 1.47, 'red': 1.88},
}


def evaluate_sequence_flag(metric, value, chain_type):
    if not THRESHOLDS_THERASABDAB:
        return ""
    if "VHH" not in THRESHOLDS_THERASABDAB:
        return ""
    t = THRESHOLDS_THERASABDAB["VHH"].get(chain_type, {}).get(metric)
    if not t or ('count' in t and t['count'] == 0 and 'red_low' not in t and 'p0' not in t):
        return ""
    try:
        val = float(value)
        if np.isnan(val): return "UNKNOWN"
        if 'p0' in t:
            if val < t['p0'] or val > t['p100']: return "RED"
            if val < t['p5'] or val > t['p95']: return "AMBER"
            if val < t['p10'] or val > t['p90']: return "LIGHT_GREEN"
            if val < t['p25'] or val > t['p75']: return "MID_GREEN"
            return "DARK_GREEN"
        else:
            if val < t.get('red_low', -999999) or val > t.get('red_high', 999999): return "RED"
            if (t.get('red_low', -999999) <= val <= t.get('amber_low', -999999)) or (t.get('amber_high', 999999) <= val <= t.get('red_high', 999999)): return "AMBER"
            return "GREEN"
    except:
        return ""

def evaluate_flag(metric, value):
    if np.isnan(value): return "UNKNOWN"
    t = THRESHOLDS_TNP.get(metric)
    if not t or ('count' in t and t['count'] == 0 and 'red_low' not in t and 'p0' not in t): return "UNKNOWN"
    if 'p0' in t:
        if metric in ['L', 'L3', 'C', 'PSH']:
            if value < t['p0'] or value > t['p100']: return "RED"
            if value < t['p5'] or value > t['p95']: return "AMBER"
            if value < t['p10'] or value > t['p90']: return "LIGHT_GREEN"
            if value < t['p25'] or value > t['p75']: return "MID_GREEN"
            return "DARK_GREEN"
        elif metric in ['PPC', 'PNC']:
            if value > t['p100']: return "RED"
            if value > t['p95']: return "AMBER"
            if value > t['p90']: return "LIGHT_GREEN"
            if value > t['p75']: return "MID_GREEN"
            return "DARK_GREEN"
    else:
        if metric in ['L', 'L3', 'C', 'PSH']:
            if value < t.get('red_low', -999999) or value > t.get('red_high', 999999): return "RED"
            if (t.get('red_low', -999999) <= value <= t.get('amber_low', -999999)) or (t.get('amber_high', 999999) <= value <= t.get('red_high', 999999)): return "AMBER"
            return "GREEN"
        elif metric in ['PPC', 'PNC']:
            if value > t.get('red', 999999): return "RED"
            if value >= t.get('amber', 999999): return "AMBER"
            return "GREEN"
    return "GREEN"


def evaluate_ptm_flag(ptm_type, value):
    val_str = str(value)
    if not val_str or val_str == 'None':
        if ptm_type == 'Cys_Status': return "GREEN"
        return "GREEN"
    if ptm_type == 'N_Glyco_Sites':
        if val_str != 'None' and val_str != '': return "RED"
        return "GREEN"
    if ptm_type in ['Deamidation', 'Isomerization', 'Cleavage', 'Oxidation']:
        if '(DS)' in val_str or '(DG)' in val_str: return "RED"
        if '(NS)' in val_str or '(NG)' in val_str or '(NN)' in val_str: return "AMBER"
        return "GREEN"
    if ptm_type == 'Cys_Status':
        if 'Free: Yes' in val_str: return "RED"
        if 'Free: No' in val_str: return "GREEN"
    return "GREEN"

def get_exposed_via_psa(structure, psa_bin):
    model = structure[0]
    all_residues = list(model.get_residues())
    fd, tmp_path = tempfile.mkstemp(suffix=".pdb")
    os.close(fd)
    try:
        io = PDBIO()
        io.set_structure(structure)
        io.save(tmp_path)
        cmd = [psa_bin, "-t", tmp_path]
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        psa_lines = [line for line in result.stdout.splitlines() if line.startswith("ACCESS")]
        if len(psa_lines) != len(all_residues): raise ValueError()
        surface_exposed = []
        for res, line in zip(all_residues, psa_lines):
            total_side_per_str = line[61:66].strip()
            total_side_per = 100.0 if '*' in total_side_per_str else float(total_side_per_str)
            if total_side_per >= 7.5: surface_exposed.append(res)
        return surface_exposed
    finally:
        if os.path.exists(tmp_path): os.remove(tmp_path)


PTM_PATTERNS = {
    'Deamidation_Sites': r'N[GNS]',
    'Isomerization_Sites': r'D[GS]',
    'Cleavage_Sites': r'DP',
    'Oxidation_Sites': r'[MW]'
}

def predict_n_glycosylation_sites(sequence):
    glycosylation_sites = []
    for match in re.finditer(r'N[^P][ST]', sequence):
        position = match.start() + 1
        residue = sequence[max(0, match.start()):match.start()+3]
        glycosylation_sites.append(f'{position}({residue})')
    return glycosylation_sites

def find_ptm_sites(sequence, pattern):
    sites = []
    for match in re.finditer(pattern, sequence):
        position = match.start() + 1
        residue = match.group()
        sites.append(f'{position}({residue})')
    return ', '.join(sites) if sites else "None"

def check_free_cysteine(sequence):
    cys_count = sequence.count('C')
    has_free = "Yes" if cys_count % 2 != 0 else "No"
    return f"{cys_count} (Free: {has_free})"

def analyze_sequence(sequence):
    if not isinstance(sequence, str) or len(sequence.strip()) == 0:
        return {'Length': 0, 'Mol_Weight': 0.0, 'pI': 0.0, 'GRAVY': 0.0, 'Instability': 0.0, 'Charge_pH7.4': 0.0, 'N_Glyco_Count': 0, 'N_Glyco_Sites': 'None', 'Deamidation': 'None', 'Isomerization': 'None', 'Cleavage': 'None', 'Oxidation': 'None', 'Cys_Status': 'None'}
    
    sequence = sequence.strip().upper()
    clean_seq = re.sub(r'[^ACDEFGHIKLMNPQRSTVWY]', '', sequence)
    
    if len(clean_seq) == 0:
        return {'Length': 0, 'Mol_Weight': 0.0, 'pI': 0.0, 'GRAVY': 0.0, 'Instability': 0.0, 'Charge_pH7.4': 0.0, 'N_Glyco_Count': 0, 'N_Glyco_Sites': 'None', 'Deamidation': 'None', 'Isomerization': 'None', 'Cleavage': 'None', 'Oxidation': 'None', 'Cys_Status': 'None'}
        
    try:
        analyzed_seq = ProteinAnalysis(clean_seq)
        return {
            'Length': len(clean_seq),
            'Mol_Weight': round(analyzed_seq.molecular_weight(), 2),
            'pI': round(analyzed_seq.isoelectric_point(), 2),
            'GRAVY': round(analyzed_seq.gravy(), 3),
            'Instability': round(analyzed_seq.instability_index(), 2),
            'Charge_pH7.4': round(analyzed_seq.charge_at_pH(7.4), 2),
            'N_Glyco_Count': len(predict_n_glycosylation_sites(clean_seq)),
            'N_Glyco_Sites': ', '.join(predict_n_glycosylation_sites(clean_seq)) if predict_n_glycosylation_sites(clean_seq) else "None",
            'Deamidation': find_ptm_sites(clean_seq, PTM_PATTERNS['Deamidation_Sites']),
            'Isomerization': find_ptm_sites(clean_seq, PTM_PATTERNS['Isomerization_Sites']),
            'Cleavage': find_ptm_sites(clean_seq, PTM_PATTERNS['Cleavage_Sites']),
            'Oxidation': find_ptm_sites(clean_seq, PTM_PATTERNS['Oxidation_Sites']),
            'Cys_Status': check_free_cysteine(clean_seq)
        }
    except Exception as e:
        return {'Length': 0, 'Mol_Weight': 0.0, 'pI': 0.0, 'GRAVY': 0.0, 'Instability': 0.0, 'Charge_pH7.4': 0.0, 'N_Glyco_Count': 0, 'N_Glyco_Sites': 'None', 'Deamidation': 'None', 'Isomerization': 'None', 'Cleavage': 'None', 'Oxidation': 'None', 'Cys_Status': 'None'}

def process_single_structure(file_path, psa_bin):
    if file_path.lower().endswith('.cif'): parser = MMCIFParser(QUIET=True)
    else: parser = PDBParser(QUIET=True)
    structure = parser.get_structure('RAW', file_path)
    model = structure[0]
    for chain in model:
        for res in list(chain):
            if res.id[0] != ' ': chain.detach_child(res.id)
            for a in list(res):
                if a.element == 'H': res.detach_child(a.id)

    vh_chain = None
    for chain in list(model.get_chains()):
        residues = list(chain.get_residues())
        if not residues: continue
        seq = "".join([seq1(res.resname, custom_map={"UNK": "X"}) for res in residues])
        try: result = subprocess.run(["ANARCI", "--sequence", seq, "--scheme", "imgt"], capture_output=True, text=True, check=True)
        except: result = subprocess.run(["anarci", "--sequence", seq, "--scheme", "imgt"], capture_output=True, text=True, check=True)
        mapping = [] 
        h_count, l_count = 0, 0
        for line in result.stdout.splitlines():
            if line.startswith("#") or line.startswith("//") or not line.strip(): continue
            parts = line.split()
            if len(parts) >= 3 and parts[0] in ['H', 'K', 'L']:
                c_type = 'H' if parts[0] == 'H' else 'L'
                if c_type == 'H': h_count += 1
                else: l_count += 1
                if parts[-1] != '-': mapping.append((int(parts[1]), parts[-1]))
        if not mapping: 
            model.detach_child(chain.id)
            continue
        if h_count > l_count:
            chain.xtra['chain_type'] = 'H'
            vh_chain = chain
            chain.xtra['sequence'] = seq
        else:
            model.detach_child(chain.id)
            continue
        ptr = 0
        mapped_indices = []
        for m in mapping:
            while ptr < len(seq) and seq[ptr] != m[1]: ptr += 1
            if ptr < len(seq):
                mapped_indices.append(ptr)
                ptr += 1
            else: break
        for m, idx in zip(mapping, mapped_indices):
            residues[idx].xtra['imgt_num'] = m[0]

    if not vh_chain: raise ValueError("No VH/VHH detected")

    tetrad_dict = {42: '-', 49: '-', 50: '-', 52: '-'}
    for r in vh_chain:
        imgt_num = r.xtra.get('imgt_num')
        if imgt_num in tetrad_dict:
            tetrad_dict[imgt_num] = seq1(r.resname, custom_map={"UNK": "X"})
    tetrad_motif = f"{tetrad_dict[42]}{tetrad_dict[49]}{tetrad_dict[50]}{tetrad_dict[52]}"

    surface_exposed = get_exposed_via_psa(structure, psa_bin)
    salt_bridges = set()
    pos_atoms = [a for r in surface_exposed if r.resname in ['ARG', 'LYS'] for a in r if a.name in ['NH1', 'NH2', 'NZ']]
    neg_atoms = [a for r in surface_exposed if r.resname in ['ASP', 'GLU'] for a in r if a.name in ['OD1', 'OD2', 'OE1', 'OE2']]
    for p in pos_atoms:
        for n in neg_atoms:
            if p - n < 3.2:
                salt_bridges.add(p.get_parent())
                salt_bridges.add(n.get_parent())

    patch_properties = {}
    for res in surface_exposed:
        original_q = CHARGE_SCALE.get(res.resname, 0.0) 
        if res in salt_bridges: patch_properties[res] = {'Q': original_q, 'H': normalize_kd('GLY')}
        else: patch_properties[res] = {'Q': original_q, 'H': normalize_kd(res.resname)}

    cdr_and_anchors = [r for r in surface_exposed if r.xtra.get('imgt_num') in IMGT_CDR_ANCHORS]
    total_cdr_length = sum(1 for c in model for r in c if r.xtra.get('imgt_num') and any(s <= r.xtra['imgt_num'] <= e for s,e in [(27,38),(56,65),(105,117)]))
    cdr3_length = sum(1 for c in model for r in c if r.xtra.get('imgt_num') and 105 <= r.xtra['imgt_num'] <= 117)
    
    h3_loop_coords = []
    h3_anchor_coords = []
    for r in vh_chain:
        imgt_num = r.xtra.get('imgt_num')
        if not imgt_num: continue
        backbone_atoms = [a.coord for a in r if a.name in ['N', 'CA', 'C']]
        if 105 <= imgt_num <= 117: h3_loop_coords.extend(backbone_atoms)
        if imgt_num in [102, 103, 118, 119]: h3_anchor_coords.extend(backbone_atoms)
            
    if h3_loop_coords and h3_anchor_coords:
        h_centroid = np.mean(h3_loop_coords, axis=0)
        c_centroid = np.mean(h3_anchor_coords, axis=0)
        rho = np.linalg.norm(h_centroid - c_centroid)
        compactness = (cdr3_length / rho) if rho > 0 else np.nan
    else: compactness = np.nan
    
    cdr_coords = [a.coord for r in cdr_and_anchors for a in r]
    vicinity = set(cdr_and_anchors)
    for res in surface_exposed:
        if res not in vicinity and [a.coord for a in res] and cdr_coords:
            if np.min(cdist([a.coord for a in res], cdr_coords)) <= 4.0:
                vicinity.add(res)
    vicinity_list = list(vicinity)
    psh, ppc, pnc = 0.0, 0.0, 0.0
    for i in range(len(vicinity_list)):
        for j in range(i + 1, len(vicinity_list)):
            r1, r2 = vicinity_list[i], vicinity_list[j]
            c1, c2 = [a.coord for a in r1], [a.coord for a in r2]
            if c1 and c2:
                r12 = np.min(cdist(c1, c2))
                if r12 < 7.5:
                    r12_sq = r12 ** 2
                    psh += (patch_properties[r1]['H'] * patch_properties[r2]['H']) / r12_sq
                    q1, q2 = patch_properties[r1]['Q'], patch_properties[r2]['Q']
                    if q1 > 0 and q2 > 0: ppc += (q1 * q2) / r12_sq
                    if q1 < 0 and q2 < 0: pnc += (abs(q1) * abs(q2)) / r12_sq
    psh *= 2; ppc *= 2; pnc *= 2

    
    vhh_seq = vh_chain.xtra.get('sequence', '')
    prop_VHH = analyze_sequence(vhh_seq)
    
    return { 'Tetrad': tetrad_motif, 'L': total_cdr_length, 'L3': cdr3_length, 'C': compactness, 'PSH': psh, 'PPC': ppc, 'PNC': pnc, 'prop_VHH': prop_VHH }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("--output", "-o")
    parser.add_argument("--psa_bin", default="psa")
    args = parser.parse_args()
    
    target_files = []
    input_abspath = os.path.abspath(args.input)
    if os.path.isdir(input_abspath):
        base_dir = input_abspath
        for root, dirs, files in os.walk(input_abspath):
            for f in files:
                if f.lower().endswith(('.pdb', '.cif')): target_files.append(os.path.join(root, f))
    elif os.path.isfile(input_abspath):
        target_files.append(input_abspath)
        base_dir = os.path.dirname(input_abspath)
    else: sys.exit(1)

    target_files.sort(key=lambda x: os.path.basename(x).lower())
    if not args.output:
        result_dir = os.path.join(base_dir, 'result')
        os.makedirs(result_dir, exist_ok=True)
        args.output = os.path.join(result_dir, 'tnp_results.csv')

    csv_file = open(args.output, 'w', newline='', encoding='utf-8')
    csv_writer = csv.writer(csv_file)
    csv_writer.writerow(["Filename", "Status", "Tetrad", "L_Value", "L_Flag", "L3_Value", "L3_Flag", "C_Value", "C_Flag", "PSH_Value", "PSH_Flag", "PPC_Value", "PPC_Flag", "PNC_Value", "PNC_Flag", "VHH_Length", "VHH_MW_Value", "VHH_MW_Flag", "VHH_pI_Value", "VHH_pI_Flag", "VHH_GRAVY_Value", "VHH_GRAVY_Flag", "VHH_Instability_Value", "VHH_Instability_Flag", "VHH_Charge_Value", "VHH_Charge_Flag", "VHH_NGlyc", "VHH_NGlycSites_Value", "VHH_NGlycSites_Flag", "VHH_Deamidation_Value", "VHH_Deamidation_Flag", "VHH_Isomerization_Value", "VHH_Isomerization_Flag", "VHH_Cleavage_Value", "VHH_Cleavage_Flag", "VHH_Oxidation_Value", "VHH_Oxidation_Flag", "VHH_Cys_Value", "VHH_Cys_Flag", "Error_Message"])

    for filepath in target_files:
        filename = os.path.basename(filepath)
        try:
            res = process_single_structure(filepath, args.psa_bin)
            pH = res['prop_VHH']
            csv_writer.writerow([
                filename, "SUCCESS", res['Tetrad'],
                f"{res['L']:.0f}", evaluate_flag('L', res['L']),
                f"{res['L3']:.0f}", evaluate_flag('L3', res['L3']),
                f"{res['C']:.6f}" if not np.isnan(res['C']) else "NaN", evaluate_flag('C', res['C']),
                f"{res['PSH']:.6f}", evaluate_flag('PSH', res['PSH']),
                f"{res['PPC']:.6f}", evaluate_flag('PPC', res['PPC']),
                f"{res['PNC']:.6f}", evaluate_flag('PNC', res['PNC']),
                f"{pH['Length']}",
                f"{pH.get('Mol_Weight', 0):.1f}", evaluate_sequence_flag('Mol_Weight', pH.get('Mol_Weight', 0), 'VHH'),
                f"{pH.get('pI', 0):.2f}", evaluate_sequence_flag('pI', pH.get('pI', 0), 'VHH'),
                f"{pH.get('GRAVY', 0):.3f}", evaluate_sequence_flag('GRAVY', pH.get('GRAVY', 0), 'VHH'),
                f"{pH.get('Instability', 0):.2f}", evaluate_sequence_flag('Instability', pH.get('Instability', 0), 'VHH'),
                f"{pH.get('Charge_pH7.4', 0):.2f}", evaluate_sequence_flag('Charge_pH7.4', pH.get('Charge_pH7.4', 0), 'VHH'),
                f"{pH.get('N_Glyco_Count', 0)}",
                f"{pH.get('N_Glyco_Sites', '')}", evaluate_ptm_flag('N_Glyco_Sites', pH.get('N_Glyco_Sites', '')),
                f"{pH.get('Deamidation', '')}", evaluate_ptm_flag('Deamidation', pH.get('Deamidation', '')),
                f"{pH.get('Isomerization', '')}", evaluate_ptm_flag('Isomerization', pH.get('Isomerization', '')),
                f"{pH.get('Cleavage', '')}", evaluate_ptm_flag('Cleavage', pH.get('Cleavage', '')),
                f"{pH.get('Oxidation', '')}", evaluate_ptm_flag('Oxidation', pH.get('Oxidation', '')),
                f"{pH.get('Cys_Status', '')}", evaluate_ptm_flag('Cys_Status', pH.get('Cys_Status', '')),
                ""
            ])
        except Exception as e:
            csv_writer.writerow([filename, "FAILED"] + [""]*37 + [str(e)])
    csv_file.close()

if __name__ == "__main__": main()
